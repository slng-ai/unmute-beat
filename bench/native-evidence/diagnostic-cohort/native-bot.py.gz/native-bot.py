"""Generated Pipecat agent for salon-concierge.

Compiled by `unmute`; do not edit by hand. Prompts, model routes, and the agent
graph are baked in from the package. Secret values are read from the environment
and never written here. The agency model uses the Pipecat workers API: a main
PipelineWorker owns the transport + STT, each agent is an LLMWorker with its own
LLM and voice, and agent_transfer is activate_worker(). Tasks and task groups
run as Pipecat Flows on the owning agent: a delegate tool snapshots the shared
context, a FlowManager walks the steps as nodes, and control returns with only
a completed or unserved status.
"""

from __future__ import annotations

import asyncio
import copy
import functools
import inspect
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from typing import Annotated, Literal
from urllib.parse import quote
from zoneinfo import ZoneInfo
import tools.find_or_create_customer
import tools.find_slots
import tools.record_complaint
import tools.save_booking
from dotenv import load_dotenv
from loguru import logger
from pydantic import AfterValidator, BaseModel, Field, TypeAdapter, ValidationError

from pipecat.audio.turn.smart_turn.base_smart_turn import SmartTurnParams
from pipecat.audio.turn.smart_turn.local_smart_turn_v3 import LocalSmartTurnAnalyzerV3
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.bus import BusBridgeProcessor
from pipecat.flows import FlowManager, FlowsFunctionSchema, NodeConfig, NO_RESPONSE
from pipecat.frames.frames import (
    EndFrame,
    FunctionCallResultProperties,
    LLMMessagesAppendFrame,
    LLMRunFrame,
    LLMUpdateSettingsFrame,
    TTSSpeakFrame,
)
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.worker import PipelineParams, PipelineWorker
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.runner.types import RunnerArguments
from pipecat.runner.utils import create_transport
from pipecat.services.llm_service import FunctionCallParams
from pipecat.services.settings import LLMSettings
from pipecat.transcriptions.language import Language
from pipecat.transports.base_transport import BaseTransport, TransportParams
from pipecat.transports.websocket.fastapi import FastAPIWebsocketParams
from pipecat.turns.user_stop import TurnAnalyzerUserTurnStopStrategy
from pipecat.turns.user_turn_strategies import UserTurnStrategies
from pipecat.turns.user_mute import MuteUntilFirstBotCompleteUserMuteStrategy
from pipecat.workers.llm import LLMWorkerActivationArgs, tool
from pipecat.workers.runner import WorkerRunner

from dev_metrics import install_dev_metrics
from tracing import (
    TRACE_NAME,
    TracedLLMWorker,
    enable_agent_tracing,
    flush_tracing,
    setup_langfuse_tracing,
    start_call,
)

from pipecat.services.google.llm import GoogleLLMService
from pipecat_slng import SlngSTTService
from pipecat_slng import SlngTTSService


def _google_vertex_client(api_key, location):
    from google import genai

    # Match the POC's API-key Express Mode routing; region is not pinned.
    assert location == "global"
    return genai.Client(vertexai=True, api_key=api_key)


class _GoogleVertexLLM(GoogleLLMService):
    def __init__(self, *, location, **kwargs):
        self._vertex_location = location
        super().__init__(**kwargs)

    def create_client(self):
        self._client = _google_vertex_client(self._api_key, self._vertex_location)


load_dotenv()

_LOGGING_CONFIGURED = False


def _configure_logging() -> None:
    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED:
        return
    logger.remove()
    logger.add(sys.stderr, level=os.getenv("UNMUTE_LOG_LEVEL", "INFO").upper())
    _LOGGING_CONFIGURED = True


MAIN_NAME = "main"
# What every session needs, whatever channel it arrives on. What a *phone call*
# adds is CALL_REQUIRED_ENV below, checked separately, so this package still runs
# in the browser with nothing but model keys (V10/B3).
REQUIRED_ENV = [
    "GOOGLE_API_KEY",
    "LANGFUSE_BASE_URL",
    "LANGFUSE_PUBLIC_KEY",
    "LANGFUSE_SECRET_KEY",
    "NATIVE_CALL_ID",
    "OPENAI_API_KEY",
    "SLNG_API_KEY",
]


def require_env() -> None:
    missing = [name for name in REQUIRED_ENV if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            f"Missing required environment variables: {', '.join(missing)}"
        )


def _direct_tool(
    fn=None, *, cancel_on_interruption=True, timeout_secs=None, announce=None
):
    """Keep every direct function call terminal, even on malformed input."""

    def decorate(handler):
        signature = inspect.signature(handler)
        declared = set(signature.parameters) - {"self", "params"}

        @functools.wraps(handler)
        async def guarded(*args, **kwargs):
            params = kwargs.get("params")
            if params is None:
                params_index = 1 if "self" in signature.parameters else 0
                params = args[params_index]

            unexpected = sorted(set(kwargs) - declared - {"params"})
            if unexpected:
                allowed = ", ".join(sorted(declared)) or "none"
                await params.result_callback(
                    {
                        "error": (
                            f"Unexpected arguments for {params.function_name}: "
                            f"{', '.join(unexpected)}. Allowed arguments: {allowed}. "
                            "Retry with only allowed arguments."
                        )
                    }
                )
                return

            if announce:
                # Cover the wait: TTSSpeakFrame is a DataFrame, so it is queued
                # and speech starts while the handler body runs. Nothing waits
                # for playout here, which is the point of the line. Queued after
                # the argument check, so a rejected call stays silent, and an
                # interruption discards it in line with cancel_on_interruption.
                await params.llm.push_frame(TTSSpeakFrame(announce))

            resolved = False
            original_result_callback = params.result_callback

            async def resolve(result, **callback_kwargs):
                nonlocal resolved
                resolved = True
                return await original_result_callback(result, **callback_kwargs)

            params.result_callback = resolve
            try:
                return await handler(*args, **kwargs)
            except Exception:
                logger.exception(
                    "tool failed before completing: {}", params.function_name
                )
                if not resolved:
                    await original_result_callback(
                        {
                            "error": (
                                f"{params.function_name} failed before completing. "
                                "Do not claim success; retry only with corrected input."
                            )
                        }
                    )
                    return
                raise
            finally:
                params.result_callback = original_result_callback

        return tool(
            cancel_on_interruption=cancel_on_interruption,
            timeout_secs=timeout_secs,
        )(guarded)

    if fn is not None:
        return decorate(fn)
    return decorate


# Checked at import, which is what makes the container refuse to start rather
# than start and go quiet.
#
# It used to be checked only inside run_bot, once per session. The container
# then reported healthy, the platform marked the deployment ready, the browser
# got a valid answer to its offer — and the failure happened in a background
# task where only the log saw it. A caller heard silence. That is the exact
# trade Principle II calls the worst one available, and two documentation pages
# already promised the opposite: "the container starts, checks the keys the
# agent needs, and stops with the names it did not find" (Wave C, 2026-08-15).
#
# run_bot still calls it, because a session that somehow starts without them
# should fail before the caller hears anything either.
require_env()


# --- the carrier stream ------------------------------------------------------
# Your carrier streams the call's audio straight to Pipecat Cloud, which starts
# this agent. Nothing of yours is in the path, so there is nothing here that
# answers a webhook or holds a call open. The runner has already parsed the
# carrier's handshake by the time run_bot starts; everything below reads that
# parsed result and never re-parses it.

# What a phone call adds to REQUIRED_ENV above, checked only on a phone call: a
# browser or console session on this package reads none of these and must not be
# asked for them. The check runs before the caller hears anything, so a missing
# value can never first show up as a failed transfer on a call somebody is
# paying for.
CALL_REQUIRED_ENV = [
    "TWILIO_ACCOUNT_SID",
    "TWILIO_AUTH_TOKEN",
    "TWILIO_PHONE_NUMBER",
]


def _phone_session(runner_args: RunnerArguments) -> dict | None:
    """The parsed carrier handshake, or None when this is not a phone call.

    The runner sets transport_type and call_data while building the transport, so
    this reads facts rather than deriving them. A browser or console session has
    neither and must behave exactly as it does on a package with no telephony.
    """
    if getattr(runner_args, "transport_type", None) != "twilio":
        return None
    missing = [name for name in CALL_REQUIRED_ENV if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            f"Missing environment for a phone call: {', '.join(missing)}"
        )
    call = dict(getattr(runner_args, "call_data", None) or {})
    direction = (call.get("body") or {}).get("direction", "inbound")
    logger.info("phone call {} ({})", call.get("call_id"), direction)
    return call


def _pipeline_audio_rates(phone_call: dict | None) -> dict:
    """Run the pipeline at the carrier's own sample rate, on a phone call only.

    Twilio Media Streams is 8 kHz mono in both directions. Pipecat's defaults are
    16 kHz in and 24 kHz out, so without this every inbound frame is upsampled and
    every outbound frame is downsampled, for the whole call, in exchange for no
    information at all: there is nothing above 4 kHz in the audio to recover. The
    transport's own guide asks for these two values for exactly that reason.

    A browser or console session on the same package keeps the defaults, where
    8 kHz would throw away quality those channels really have.
    """
    if not phone_call:
        return {}
    return {"audio_in_sample_rate": 8000, "audio_out_sample_rate": 8000}


# --- declared state ----------------------------------------------------------
# Generated from the `shapes:` and the typed `variables:` in agent.yaml. Both
# target frameworks already depend on Pydantic, so nothing here adds one. The one
# exception is EmailStr, which is checked by email-validator: declaring it puts
# that package in this project's pyproject.toml, and declaring no email type
# leaves both the import and the dependency out.
#
# Emitted from one place in the compiler for both targets, so the classes, the
# checks and the refusal wording cannot differ between them.

_SHAPE_PHONE = re.compile(r"^\+[1-9]\d{6,14}$")


def _shape_phone(value: str) -> str:
    # Empty is not a wrong value, it is no value yet. It is what a declared
    # variable holds before anything fills it, what an empty prompt reference
    # renders as words, and what a tool hands back for a field it could not fill. Refusing
    # it here deadlocked a live call on both targets: the model had nothing else
    # to send, so every retry was refused the same way and the step never
    # finished. A wrong value is still refused; an absent one is not wrong.
    if value and not _SHAPE_PHONE.match(value):
        raise ValueError(
            "expected a phone number in E.164, one leading plus and 7 to 15 digits, like +34600111222"
        )
    return value


# AfterValidator and never a pattern= constraint: a pattern reaches the schema
# the model is sent, one target's strict converter keeps it, and the provider
# rejects it. So the schema says str and the shape is checked here.
#
# The description is how the format reaches the model at all, and it is the only
# keyword that can: it travels as prose, so no strict converter strips it. A
# field that said nothing about its shape was learned from a refusal mid-call,
# which cost a model round trip on every value the prompt spells one way and
# this type another. A field carrying its own description keeps that one; the
# emitter appends this phrase to it.
Phone = Annotated[
    str,
    AfterValidator(_shape_phone),
    Field(
        description="a phone number in E.164, one leading plus and 7 to 15 digits, like +34600111222"
    ),
]

_SHAPE_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _shape_date(value: str) -> str:
    # Empty is not a wrong value, it is no value yet. It is what a declared
    # variable holds before anything fills it, what an empty prompt reference
    # renders as words, and what a tool hands back for a field it could not fill. Refusing
    # it here deadlocked a live call on both targets: the model had nothing else
    # to send, so every retry was refused the same way and the step never
    # finished. A wrong value is still refused; an absent one is not wrong.
    if value and not _SHAPE_DATE.match(value):
        raise ValueError("expected a day written year-month-day, like 2026-03-19")
    return value


# AfterValidator and never a pattern= constraint: a pattern reaches the schema
# the model is sent, one target's strict converter keeps it, and the provider
# rejects it. So the schema says str and the shape is checked here.
#
# The description is how the format reaches the model at all, and it is the only
# keyword that can: it travels as prose, so no strict converter strips it. A
# field that said nothing about its shape was learned from a refusal mid-call,
# which cost a model round trip on every value the prompt spells one way and
# this type another. A field carrying its own description keeps that one; the
# emitter appends this phrase to it.
Date = Annotated[
    str,
    AfterValidator(_shape_date),
    Field(description="a day written year-month-day, like 2026-03-19"),
]

_SHAPE_TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def _shape_time(value: str) -> str:
    # Empty is not a wrong value, it is no value yet. It is what a declared
    # variable holds before anything fills it, what an empty prompt reference
    # renders as words, and what a tool hands back for a field it could not fill. Refusing
    # it here deadlocked a live call on both targets: the model had nothing else
    # to send, so every retry was refused the same way and the step never
    # finished. A wrong value is still refused; an absent one is not wrong.
    if value and not _SHAPE_TIME.match(value):
        raise ValueError(
            "expected a time of day on the 24-hour clock, like 09:30 or 17:45"
        )
    return value


# AfterValidator and never a pattern= constraint: a pattern reaches the schema
# the model is sent, one target's strict converter keeps it, and the provider
# rejects it. So the schema says str and the shape is checked here.
#
# The description is how the format reaches the model at all, and it is the only
# keyword that can: it travels as prose, so no strict converter strips it. A
# field that said nothing about its shape was learned from a refusal mid-call,
# which cost a model round trip on every value the prompt spells one way and
# this type another. A field carrying its own description keeps that one; the
# emitter appends this phrase to it.
Time = Annotated[
    str,
    AfterValidator(_shape_time),
    Field(description="a time of day on the 24-hour clock, like 09:30 or 17:45"),
]

_SHAPE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")


def _shape_id(value: str) -> str:
    # Empty is not a wrong value, it is no value yet. It is what a declared
    # variable holds before anything fills it, what an empty prompt reference
    # renders as words, and what a tool hands back for a field it could not fill. Refusing
    # it here deadlocked a live call on both targets: the model had nothing else
    # to send, so every retry was refused the same way and the step never
    # finished. A wrong value is still refused; an absent one is not wrong.
    if value and not _SHAPE_ID.match(value):
        raise ValueError(
            "expected an identifier: letters, digits, and then any of dot, dash, underscore or colon"
        )
    return value


# AfterValidator and never a pattern= constraint: a pattern reaches the schema
# the model is sent, one target's strict converter keeps it, and the provider
# rejects it. So the schema says str and the shape is checked here.
#
# The description is how the format reaches the model at all, and it is the only
# keyword that can: it travels as prose, so no strict converter strips it. A
# field that said nothing about its shape was learned from a refusal mid-call,
# which cost a model round trip on every value the prompt spells one way and
# this type another. A field carrying its own description keeps that one; the
# emitter appends this phrase to it.
Id = Annotated[
    str,
    AfterValidator(_shape_id),
    Field(
        description="an identifier: letters, digits, and then any of dot, dash, underscore or colon"
    ),
]


class Appointment(BaseModel):
    """The latest booking successfully created, moved, or cancelled."""

    booking_id: Id
    service: Literal["haircut", "hair-color", "blowout"]
    date: Date
    spoken: str
    time: Time
    action: Literal["book", "move", "cancel"]


class _StateRefused(Exception):
    """A value that does not fit its declared type, refused where it enters.

    Carried as an exception rather than a return so the write cannot happen by
    accident: the previous contents stay exactly as they were, and the message
    goes back to the model, which is what lets it correct itself on the next
    turn instead of the step recording something wrong.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


def _typed(field, adapter, value):
    """Validate one value entering the declared state."""
    try:
        return adapter.validate_python(value)
    except ValidationError as error:
        first = error.errors()[0]
        where = ".".join(str(part) for part in first["loc"])
        named = f"{field}.{where}" if where else field
        raise _StateRefused(f"{named}: {first['msg']}") from None


def _append_entry(entries, value):
    """One entry onto a declared list, unless it is already on it.

    A step re-entered mid-call can read a value through an explicit prompt
    reference and hand it straight back, which is not a second thing happening. One live call
    entered the booking step four times and finished three of them immediately,
    each with the same appointment it had recorded on the first, so one booking
    became four entries and the caller's recap listed a booking four times.

    An object carries its own identity, so an identical one is the same thing
    reported twice. A plain value is not: two bookings really do give two
    reasons of "create_booking", and both of those count. So the skip is for
    structured entries only.

    Nothing absent is added either, which is how a step that concluded nothing
    this time finishes without inventing an entry.
    """
    if value is None:
        return
    if isinstance(value, (dict, list)) and value in entries:
        return
    entries.append(value)


def _plain(value):
    """A validated value as plain data.

    Plain data is the only shape both frameworks accept back from a tool: one
    refuses a BaseModel outright and drops the whole tool result with a log
    line, the other cannot serialise one at all.
    """
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, list):
        return [_plain(entry) for entry in value]
    if isinstance(value, dict):
        return {key: _plain(entry) for key, entry in value.items()}
    return value


def _schema(adapter):
    """One declared type's schema, with every $ref resolved into place.

    Pydantic emits $defs and a $ref for a shape that contains another shape, and
    this is not a formatting preference. Measured on one real request to the
    provider, three ways:

    - the schema as Pydantic emits it, nested inside one tool property with no
      strict flag: accepted with a 200, and the model invented field names for
      the nested object because it never read the definition. Every result would
      then have been refused where it entered, on every call.
    - the same schema with the refs inlined: accepted, and the model filled the
      shape's own fields exactly, the nullable one included.
    - the shape the other target sends, with the $defs hoisted to the
      parameters root and strict on: accepted, and correct. A $defs anywhere but
      that root is a 400 naming the pointer.

    This target nests the schema inside one property and sends no strict flag,
    so it is the first case unless the refs are resolved here.
    """
    schema = adapter.json_schema()
    defs = schema.pop("$defs", {})

    def resolve(node):
        if isinstance(node, list):
            return [resolve(item) for item in node]
        if not isinstance(node, dict):
            return node
        target = node.get("$ref")
        if isinstance(target, str) and target.startswith("#/$defs/"):
            found = defs.get(target.rsplit("/", 1)[1], {})
            siblings = {key: value for key, value in node.items() if key != "$ref"}
            return {**resolve(found), **siblings}
        return {key: resolve(value) for key, value in node.items()}

    return resolve(schema)


_FINISH_TYPES = {
    "manage_booking": {
        "appointment": TypeAdapter(
            Annotated[
                Appointment,
                Field(
                    description="The latest successful booking action, saved only after the tool succeeds."
                ),
            ]
        ),
    },
    "verify_customer": {
        "customer_phone": TypeAdapter(
            Annotated[
                Phone,
                Field(
                    description="The caller's phone number in E.164: a plus sign, then digits, with no spaces, brackets or dashes. One shape for every phone number in this package, the MANAGER_PHONE_NUMBER transfer destination included, so no prompt and no tool has to guess which shape it is holding.\nNo `source:` here on purpose. The prefetch block below reads the carrier's fact and this variable receives it, which leaves the per-route refusal for a variable naming a source its target cannot supply exactly as strict as it is: on a route with no caller ID the entry skips and this holds its default.\nOffered to the caller for a yes, never acted on unasked. Somebody may be ringing from a friend's phone, or may hold a second account, so until the verification step has heard them agree this value stays unconfirmed and appears in no prompt but that step's own."
                ),
            ]
        ),
        "customer_status": TypeAdapter(
            Annotated[
                str,
                Field(
                    description="Whether verification has already run on this call, and what it found. Set by the verification step as it ends, which only happens on a number the caller agreed to, so a value here means the number beside it is confirmed.\nIt exists for customer care, which has to decide whether to identify the caller before writing a complaint down and cannot read `customer_phone` to find out: an unconfirmed number renders in no prompt but the verification step's own, and a confirmed one must not be in front of an agent that might say it out loud. This carries the same fact with nothing sensitive in it.\nThe concierge does not read it. The `book` flow decides the same thing structurally with `skip_when_confirmed:`, off the confirmation itself rather than off a copy of it.\nEmpty means nobody has been verified yet on this call."
                ),
            ]
        ),
    },
}


def _task_status(values):
    return {"status": "unserved" if values.get("unserved_request") else "completed"}


def _group_status(results):
    return {
        "status": "unserved"
        if any(value.get("unserved_request") for value in results.values())
        else "completed"
    }


def _typed_result(step, values):
    """Validate a step's declared results where they enter the state.

    Refused here rather than carried into a later step that assumes it is
    right, and refused on both targets rather than on the one whose framework
    happens to validate tool arguments: one of them validates through Pydantic
    and lets the model self-correct, the other splats raw JSON into the handler.
    """
    if values.get("unserved_request"):
        return {"unserved_request": values["unserved_request"]}
    adapters = _FINISH_TYPES.get(step)
    if not adapters:
        return values
    out = dict(values)
    for name, adapter in adapters.items():
        # Absent goes through the adapter too, rather than being skipped. A
        # field the model left out is a field with no value, and that is what a
        # prompt telling it to leave one out asks for: a value that may be
        # absent validates as None and the append drops it, and a value that
        # may not is refused here with the message that lets the model correct
        # itself. Skipping an absent field instead left the key missing from
        # the result, and the assignment that reads it by name raised a
        # KeyError inside the finish handler on the target whose framework
        # validates no argument of its own.
        out[name] = _plain(_typed(name, adapter, out.get(name)))
    return out


_STATE_TYPES = {
    "appointment": TypeAdapter(Appointment),
    "booking_date": TypeAdapter(Date),
    "booking_weekday": TypeAdapter(str),
    "customer_phone": TypeAdapter(Phone),
    "customer_verified": TypeAdapter(str),
    "salon_local_time": TypeAdapter(Time),
}
_TASK_ASSIGNMENTS = {
    "manage_booking": [
        ("appointment", "appointment", False),
    ],
    "verify_customer": [
        ("customer_phone", "customer_phone", False),
        ("customer_verified", "customer_status", False),
    ],
}
_STATE_CONFIRM = {
    "customer_phone": "verify_customer",
}
_STATE_DEPENDENCIES = {}


def _save_result(step, state, values):
    """Validate all assignments before changing any call state."""
    values = _typed_result(step, values)
    if values.get("unserved_request"):
        return values
    pending = {}
    for name, path, append in _TASK_ASSIGNMENTS.get(step, ()):
        value = values
        for part in path.split("."):
            value = value.get(part) if isinstance(value, dict) else None
        if append:
            if value is None:
                continue
            entries = list(getattr(state, name, None) or [])
            _append_entry(entries, value)
            value = entries
        pending[name] = _plain(_typed(name, _STATE_TYPES[name], value))
    _save_batch(state, pending, step=step)
    return values


def _save_batch(state, values, *, step=None, inputs=None):
    """Commit a validated batch and invalidate older results of changed inputs."""
    if not values:
        return
    pending = {
        name: _plain(_typed(name, _STATE_TYPES[name], value))
        for name, value in values.items()
    }
    unconfirmed: set[str] = set(getattr(state, "_unconfirmed", ()))
    provenance = dict(getattr(state, "_prefetch_provenance", {}))
    affected = {
        name for name, value in pending.items() if getattr(state, name, None) != value
    }
    while True:
        more = {
            name for name, reads in provenance.items() if set(reads) & affected
        } - affected
        if not more:
            break
        affected.update(more)
    invalidated = affected - pending.keys()
    for name in invalidated:
        provenance.pop(name, None)
    for name, value in pending.items():
        if inputs is not None:
            provenance[name] = tuple(inputs)
        else:
            provenance.pop(name, None)
        if name in _STATE_CONFIRM:
            if _STATE_CONFIRM[name] == step and value is not None and value != "":
                unconfirmed.discard(name)
            else:
                unconfirmed.add(name)

    def current(name):
        return (
            None
            if name in invalidated
            else pending.get(name, getattr(state, name, None))
        )

    # Dependencies are acyclic: prefetch can only read earlier entries.
    for _ in range(len(_STATE_DEPENDENCIES) + 1):
        before = set(unconfirmed)
        for name, reads in _STATE_DEPENDENCIES.items():
            if (
                current(name) is not None
                and current(name) != ""
                and all(
                    source not in unconfirmed
                    and current(source) is not None
                    and current(source) != ""
                    for source in reads
                )
            ):
                unconfirmed.discard(name)
            else:
                unconfirmed.add(name)
        if before == unconfirmed:
            break
    for name in invalidated:
        setattr(state, name, None)
    for name, value in pending.items():
        setattr(state, name, value)
    if hasattr(state, "_unconfirmed"):
        state._unconfirmed = unconfirmed
    if inputs is not None or hasattr(state, "_prefetch_provenance"):
        state._prefetch_provenance = provenance


def _success_word(value):
    """One result value as a success pair reads it.

    The pairs come out of YAML as text, so a boolean has to read as the word the
    author wrote rather than as Python's own spelling of it: True never matches
    the word true, and the step would silently never end.
    """
    if isinstance(value, bool):
        return "true" if value else "false"
    return "" if value is None else str(value)


def _terminal_success(result, success):
    """Whether a tool result means this step is done.

    Every field is required and its value has to be one of the listed ones.
    Anything else is an ordinary result and goes back to the model, which is
    what keeps a failed booking a conversation rather than a saved one.
    """
    if not isinstance(result, dict):
        return False
    # The loop variable is name, not field: a package declaring a list imports
    # dataclasses' own field, and a loop variable of that name shadows it.
    for name, values in success.items():
        if _success_word(result.get(name)) not in values:
            return False
    return True


def _merge_retained(step, args, retained):
    """The model's finish arguments with the tool's own values put back.

    Reached only when a save was refused and the model is repairing it. A field
    the tool returned validly is the authoritative one: the model cannot
    manufacture a booking reference, and a repair that retyped one would record
    a booking nobody made. A retained value that does not validate is left to
    the model, because refusing here would leave the step with no way out.
    """
    out = dict(args)
    for name, adapter in _FINISH_TYPES.get(step, {}).items():
        if name not in retained:
            continue
        try:
            _typed(name, adapter, retained[name])
        except _StateRefused:
            continue
        out[name] = retained[name]
    return out


def _is_confirmed(state, name):
    """Whether a value is confirmed right now.

    Both halves matter: a value nobody has agreed to is unconfirmed, and so is
    one that was withdrawn. A group reads this once, as it starts, to decide
    whether the step that confirms it has to run.
    """
    value = getattr(state, name, None)
    return (
        name not in getattr(state, "_unconfirmed", ())
        and value is not None
        and value != ""
    )


def _withdraw_confirmation(state, step):
    """Withdraw what this step confirms, because this step is about to run again.

    A step a group may skip cannot be trusted to have confirmed anything once it
    is entered: the caller is correcting the value, or the step is running
    because the confirmation had already lapsed. Values derived from a withdrawn
    one follow it, through the same dependency pass a save runs.

    Scoped to the steps a group names with skip_when_confirmed:, so a package
    that names none behaves exactly as it did.
    """
    withdrawn = {name for name, owner in _STATE_CONFIRM.items() if owner == step}
    if not withdrawn:
        return
    unconfirmed = set(getattr(state, "_unconfirmed", ())) | withdrawn
    # Dependencies are acyclic, so one pass per entry settles them. The same
    # loop _save_batch runs, deliberately not shared with it: sharing would mean
    # editing a function every package emits, and every package that writes none
    # of this has to keep emitting exactly what it emitted.
    for _ in range(len(_STATE_DEPENDENCIES) + 1):
        before = set(unconfirmed)
        for name, reads in _STATE_DEPENDENCIES.items():
            if any(source in unconfirmed for source in reads):
                unconfirmed.add(name)
        if before == unconfirmed:
            break
    if hasattr(state, "_unconfirmed"):
        state._unconfirmed = unconfirmed
    logger.info("withdrew confirmation on entering " + step)


_STATE_STRUCTURED = {
    "appointment",
    "booking_date",
    "customer_phone",
    "salon_local_time",
}
_STATE_EMPTY = "none recorded yet."
# The bound on one rendered value, in characters. The same number the router
# bounds a template variable by, because this is the same value travelling the
# same way, and one number cannot be two.
_STATE_VALUE_MAX = 4000


def _state_text(name, value):
    """One value as a prompt reads it.

    Compact JSON for anything declared structured, never a Python repr: a repr
    writes single quotes and None, which is not JSON and is not what any
    provider produced. Words for a declared value with no contents, so a step
    cannot mistake "not yet known" for "known to be nothing".

    A value that was never declared structured renders exactly as it did before
    this existed, which is what keeps every package written before it unchanged.
    """
    if value is None or value == "":
        return _STATE_EMPTY
    if not isinstance(value, str):
        value = json.dumps(_plain(value), separators=(",", ":"), ensure_ascii=False)
    text = str(value)
    if len(text) > _STATE_VALUE_MAX:
        # The length is only knowable here, at run time, so this cannot be a
        # compile-time refusal. What it must not be is silent: a shortened value
        # is a value the model reads as complete. An f-string rather than a
        # placeholder, because this line is emitted into two modules that log
        # through two different libraries and either style prints literally on
        # the other one.
        logger.warning(
            f"declared state: {name} rendered {len(text)} characters and is shortened to "
            f"{_STATE_VALUE_MAX}; a value this long also stops the prompt being cached"
        )
        text = text[:_STATE_VALUE_MAX]
    return text


def _prompt_value(state, name, site=""):
    root, value = _state_lookup(state, name)
    if root in getattr(
        state, "_unconfirmed", ()
    ) and site != "task:" + _STATE_CONFIRM.get(root, ""):
        return root, None
    return root, value


def _state_lookup(state, name):
    """The value a placeholder names, and the declared name it belongs to.

    A path is authored {{customer.status}} and emitted {{customer__status}}: one
    flat name, because the router substitutes flat names only and both render
    paths have to agree. Everything before the first "__" is the declared value;
    each "__" after it starts a field, read as a dict key or an attribute and as
    None past an absent link, so a field of a record nobody has filled renders
    as the empty words and never raises. The root's name comes back with the
    value because the words for an empty value belong to the root variable.
    """
    root, _, path = name.partition("__")
    value = getattr(state, root, None) if state is not None else None
    for part in path.split("__") if path else ():
        if value is None:
            break
        value = (
            value.get(part) if isinstance(value, dict) else getattr(value, part, None)
        )
    return root, value


@dataclass
class State:
    """Typed call variables (SCHEMA 4.4), shared across agents."""

    _unconfirmed: set[str] = field(default_factory=lambda: set(_STATE_CONFIRM))

    appointment: Appointment | None = (
        None  # The latest successful booking action, saved only after the tool succeeds.
    )
    booking_date: Date = ""  # Today's date in the salon's own timezone, YYYY-MM-DD. Read once from the clock before the greeting, so a caller saying "tomorrow" costs one model request instead of two chained tool calls. A call that crosses midnight keeps the day it started on, which is deliberate: a date changing underneath a conversation would leave the caller and the agent disagreeing about what "tomorrow" means halfway through.
    booking_weekday: str = ""  # The weekday today falls on, spelled out in English: Monday to Sunday. From the same clock reading as `booking_date`, so the two cannot disagree about which day it is. It is what lets the agent answer "next Friday" without a second turn working out what day today is first.
    customer_phone: Phone = ""  # The caller's phone number in E.164: a plus sign, then digits, with no spaces, brackets or dashes. One shape for every phone number in this package, the MANAGER_PHONE_NUMBER transfer destination included, so no prompt and no tool has to guess which shape it is holding. No `source:` here on purpose. The prefetch block below reads the carrier's fact and this variable receives it, which leaves the per-route refusal for a variable naming a source its target cannot supply exactly as strict as it is: on a route with no caller ID the entry skips and this holds its default. Offered to the caller for a yes, never acted on unasked. Somebody may be ringing from a friend's phone, or may hold a second account, so until the verification step has heard them agree this value stays unconfirmed and appears in no prompt but that step's own.
    customer_verified: str = ""  # Whether verification has already run on this call, and what it found. Set by the verification step as it ends, which only happens on a number the caller agreed to, so a value here means the number beside it is confirmed. It exists for customer care, which has to decide whether to identify the caller before writing a complaint down and cannot read `customer_phone` to find out: an unconfirmed number renders in no prompt but the verification step's own, and a confirmed one must not be in front of an agent that might say it out loud. This carries the same fact with nothing sensitive in it. The concierge does not read it. The `book` flow decides the same thing structurally with `skip_when_confirmed:`, off the confirmation itself rather than off a copy of it. Empty means nobody has been verified yet on this call.
    salon_local_time: Time = ""  # The salon's own wall clock when the call began, HH:MM on a 24 hour clock. From the same reading as the two above. It is what lets the agent know that a caller asking for "this afternoon" at 17:40 is asking for something that has nearly passed, rather than offering them a slot that is already gone.


def _dispatched_call_start(call_context: dict | None) -> dict:
    """Input variables arrive with the dispatch: the call context on a telephony
    route, or UNMUTE_CALL_START for a local `unmute dev --var` session."""
    values = dict((call_context or {}).get("call_start", {}))
    raw = os.getenv("UNMUTE_CALL_START")
    if raw:
        try:
            supplied = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError("UNMUTE_CALL_START must be valid JSON") from exc
        if not isinstance(supplied, dict):
            raise RuntimeError("UNMUTE_CALL_START must be a JSON object")
        # The dispatch wins: env is the local stand-in for it.
        for name, value in supplied.items():
            values.setdefault(name, value)
    return values


def build_state(call_context: dict | None = None) -> State:
    state = State()
    missing = []
    call_start = _dispatched_call_start(call_context)
    if "appointment" in call_start:
        setattr(state, "appointment", call_start["appointment"])
    if "booking_date" in call_start:
        setattr(state, "booking_date", call_start["booking_date"])
    if "booking_weekday" in call_start:
        setattr(state, "booking_weekday", call_start["booking_weekday"])
    if "customer_phone" in call_start:
        setattr(state, "customer_phone", call_start["customer_phone"])
    if "customer_verified" in call_start:
        setattr(state, "customer_verified", call_start["customer_verified"])
    if "salon_local_time" in call_start:
        setattr(state, "salon_local_time", call_start["salon_local_time"])
    if missing:
        raise RuntimeError(f"Missing call context fields: {', '.join(missing)}")
    return state


_TEMPLATE = re.compile(r"\{\{\s*([a-z_][a-z0-9_]*)\s*\}\}")


def _render(text: str, state, *, quote_values: bool = False, site: str = "") -> str:
    """Substitute each variable token from the call state (SCHEMA 4.4 templates).
    Only substituted values are URL-encoded, never the surrounding literal."""
    if state is None:
        return text

    def _one(match: re.Match[str]) -> str:
        # Through _state_lookup, which walks a path emitted as one flat name, and
        # _state_text, so a declared value renders as compact JSON and an empty
        # one as words. Anything not declared structured comes back exactly as
        # str() gave it.
        value = _state_text(*_prompt_value(state, match.group(1), site))
        return quote(value, safe="") if quote_values else value

    return _TEMPLATE.sub(_one, text)


def _refusal(tool: str, state, needed: list[tuple[str, str]]) -> str:
    """Refuse a call whose injected variables are still unset (V4): the model is
    told what to do about each one, and no half-formed request is ever sent."""
    unset = [
        (name, hint)
        for name, hint in needed
        if _state_lookup(state, name)[1] in (None, "")
        # A value the caller has not agreed to is present and not usable. Without
        # this, a pre-fetched number would reach somebody else's record: the
        # request would go out against a proposal rather than a fact.
        or _state_lookup(state, name)[0] in getattr(state, "_unconfirmed", ())
    ]
    if not unset:
        return ""
    names = ", ".join(name for name, _ in unset)
    hints = " ".join(f"{name}: {hint}" for name, hint in unset if hint)
    return f"cannot call {tool} yet: {names} not set. {hints}".strip()


# Pre-fetch, generated by internal/generate/prefetch.go.
#
# Facts that are knowable before the greeting are resolved here, once per call,
# so the model is never asked to discover them. An entry whose inputs are empty
# is skipped and the values keep their declared defaults, which is what makes a
# package that pre-fetches a carrier fact still work on a route that supplies
# none. Nothing here can fail a call.
_PREFETCH_BUDGET_S = 2.0
_PREFETCH_VALUE_MAX = 512
_PREFETCH_DAYS = (
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
)
# Keypad spellings of the words a carrier substitutes when a number is
# withheld. They pass the shape check below because they are the right shape:
# digits, and about as many as a phone number has.
_PREFETCH_WITHHELD = (
    "266696687",  # anonymous
    "7378742833",  # restricted
    "8656696",  # unknown
    "86282452253",  # unavailable
    "7748283",  # private
)


def _prefetch_number(name, value):
    """A phone number, or "" when the carrier sent a placeholder instead.

    A withheld caller ID arrives three ways: empty, as the word "anonymous", or
    as the keypad digits of a word an upstream carrier sent, which is shaped like
    a real number. All three mean the same thing and all three must skip the
    entry, because a value that reaches a prompt is a value the agent reads back
    to the caller as their own number.
    """
    text = ("" if value is None else str(value)).strip()
    # E.164: a plus, then 8 to 15 digits. Anything else was not a number, which
    # covers "anonymous", "unavailable", "restricted" and an empty string alike.
    #
    # Spelled out rather than a regex so this block needs no import of its own,
    # and isascii() beside isdigit() because isdigit() is true of digits in other
    # scripts, which no carrier sends and no downstream tool would accept.
    digits = text[1:] if text.startswith("+") else text
    if not (
        text.startswith("+")
        and digits.isascii()
        and digits.isdigit()
        and 8 <= len(digits) <= 15
    ):
        if text:
            logger.info(
                f"prefetch: {name} was not a phone number, treating it as absent"
            )
        return ""
    # The digit form. Equal, or the start of a longer spelling, which is what a
    # word passed on truncated looks like.
    #
    # Only that direction. Matching a value that *begins* with a spelling would
    # throw away real numbers: "unknown" spells 8656696, and +86 5669 6xxx is an
    # ordinary Chinese mobile. A word shorter than eight digits therefore never
    # matches here, and does not need to: the shape check above already refused
    # it for being too short to be a number.
    for spelled in _PREFETCH_WITHHELD:
        if spelled.startswith(digits):
            logger.info(
                f"prefetch: {name} is a withheld-caller-ID placeholder, treating it as absent"
            )
            return ""
    return text


def _prefetch_call_facts(call_context):
    """The call's own facts, with the local seed filling only what the carrier did not.

    UNMUTE_CALL_FACTS is what `unmute dev --source name=value` sets. The
    carrier wins wherever it supplied a value: a seed stands in for a fact it
    could not supply, and never overrides one it did, so a stale value in a .env
    cannot quietly reshape a real call.

    Merging here rather than at each call site is deliberate. This driver starts a
    session from four different places, and a merge written four times is a merge
    that disagrees with itself in one of them.
    """
    facts = dict(call_context or {})
    seeded = os.environ.get("UNMUTE_CALL_FACTS")
    if not seeded:
        return facts
    try:
        values = json.loads(seeded)
        for name in values:
            if not facts.get(name):
                facts[name] = values[name]
    except (ValueError, TypeError):
        logger.warning(
            "UNMUTE_CALL_FACTS is not a JSON object of call facts; ignoring it"
        )
    return facts


def _prefetch_bounded(name, value):
    """Bound one pre-fetched value, and say so when it is shortened.

    The length is only knowable here, at run time, so this cannot be a
    compile-time refusal. Silence is the one thing it must not be.
    """
    if not isinstance(value, str):
        return value
    text = value
    if len(text) <= _PREFETCH_VALUE_MAX:
        return text
    logger.warning(
        f"prefetch: {name} was {len(text)} characters and is cut to "
        f"{_PREFETCH_VALUE_MAX}; a value this long stops the prompt being cached"
    )
    return text[:_PREFETCH_VALUE_MAX]


def _prefetch_outcome(task):
    try:
        task.result()
    except (asyncio.CancelledError, Exception):
        pass


async def _prefetch_wait(work, deadline):
    task = asyncio.create_task(work)
    task.add_done_callback(_prefetch_outcome)
    try:
        done, _ = await asyncio.wait(
            {task}, timeout=max(0, deadline - asyncio.get_running_loop().time())
        )
        if not done or asyncio.get_running_loop().time() >= deadline:
            raise TimeoutError
        return task.result()
    finally:
        if not task.done():
            task.cancel()


async def _prefetch(state, call_context) -> None:
    deadline = asyncio.get_running_loop().time() + _PREFETCH_BUDGET_S
    call_context = _prefetch_call_facts(call_context)
    # Every value awaiting the caller's agreement. The emitted _refusal helper
    # reads this set, so a tool that injects an unconfirmed value is held back,
    # and each generated assign write discards its own name as the caller
    # settles it.
    state._unconfirmed = set(_STATE_CONFIRM)
    # Entries run in the order agent.yaml lists them. Nothing here is sorted or
    # reordered: an entry reading a value a later entry assigns was refused at
    # compile time, so by here the order is known good.

    if asyncio.get_running_loop().time() >= deadline:
        return
    try:
        _now = datetime.now(ZoneInfo("Europe/Madrid"))
        _save_batch(
            state,
            {
                "booking_date": _prefetch_bounded(
                    "booking_date", _now.date().isoformat()
                ),
                "booking_weekday": _prefetch_bounded(
                    "booking_weekday", _PREFETCH_DAYS[_now.weekday()]
                ),
                "salon_local_time": _prefetch_bounded(
                    "salon_local_time", _now.strftime("%H:%M")
                ),
            },
            inputs=[],
        )
        logger.info(
            "prefetch today: resolved booking_date, booking_weekday, salon_local_time"
        )
    except TimeoutError:
        logger.warning(
            "prefetch today: startup budget expired; booking_date, booking_weekday, salon_local_time keep their defaults"
        )
        return
    except Exception:
        logger.exception(
            "prefetch today: failed; booking_date, booking_weekday, salon_local_time keep their defaults"
        )

    if asyncio.get_running_loop().time() >= deadline:
        return
    try:
        _value = (call_context or {}).get("from_number")
        _value = _prefetch_number("from_number", _value)
        if _value in (None, ""):
            logger.info("prefetch caller: skipped, the call carries no from_number")
        else:
            _save_batch(
                state,
                {"customer_phone": _prefetch_bounded("customer_phone", _value)},
                inputs=[],
            )
            logger.info(
                "prefetch caller: resolved customer_phone, awaiting confirmation"
            )
    except TimeoutError:
        logger.warning(
            "prefetch caller: startup budget expired; customer_phone keeps its default"
        )
        return
    except Exception:
        logger.exception("prefetch caller: failed; customer_phone keeps its default")


async def _end_after(worker: PipelineWorker, timeout_secs: float) -> None:
    await asyncio.sleep(timeout_secs)
    await worker.queue_frame(EndFrame())


# --- context shaping ---------------------------------------------------------


def _speech_only(messages: list) -> list[dict]:
    """history: messages, what was said out loud and no tool record.

    A tool record cannot be half-dropped. In LLMContext's standard message
    dicts, a tool call is a `tool_calls` key on an assistant message while
    only its reply carries role "tool". Filtering by role alone therefore keeps
    every call and drops everything answering it, and the provider rejects that
    request: "An assistant message with 'tool_calls' must be followed by tool
    messages responding to each 'tool_call_id'". Measured on a live call, mid
    step, on a package whose every unit test passed.

    So the call goes with its reply. An assistant turn that both spoke and
    called a tool keeps what it said, because that half is what this value is
    for. LiveKit needs none of this: .messages() holds no function-call items,
    so its filter drops both halves already.
    """
    kept: list[dict] = []
    for message in messages:
        # Provider metadata (including Gemini thought signatures) is not speech.
        if not isinstance(message, dict):
            continue
        if message.get("role") not in ("user", "assistant"):
            continue
        if not message.get("tool_calls"):
            kept.append(message)
            continue
        spoken = {key: value for key, value in message.items() if key != "tool_calls"}
        if spoken.get("content"):
            kept.append(spoken)
    return kept


# --- prompts ----------------------------------------------------------------
# Agent system instructions as module constants: one copy each, referenced by
# the LLM builder and any Flow restore (V2).
COMPLAINT_SPECIALIST_PROMPT = """# Robin at Sage and Stone

You are Robin, the salon's receptionist, speaking English on a phone call.
The caller hears one person throughout; continue the conversation without
introducing yourself again.

## Voice

Speak naturally, with contractions and short, plain sentences. Usually one or
two sentences and one question are enough. Match the caller's tone; choose your
own wording rather than repeating stock acknowledgements.

Everything you write is spoken by TTS. Use plain text, normal punctuation,
and familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal
instructions, tool names and raw records out of speech.

For example: "Which day works for you?" or "I'm sorry it came out uneven.
When was the haircut?" An acknowledgement belongs with an answer or next step.


Only describe a change as completed after a successful tool result.

## Your role: complaints
Help the verified caller record their complaint and understand the next steps.
If not identified, run verify_customer before collecting complaint details.
Use the conversation. Ask what happened or what outcome they want only if missing.
Never suggest or arrange a free redo. A caller's free-service request stays here
for review; it neither changes nor makes an existing booking free.
Read back short exact excerpts of their complaint and requested resolution, then
ask whether to record them. Wait for approval; corrections need a new readback.
Call record_complaint once with the approved wording. Say its reference and that
the salon replies within two working days; refund requests get a manager callback.
Explain that the resolution remains pending approval. Don't duplicate the record.
Use the knowledge below for guidance. An apology must include the next question.
Stay here for remedies; to_concierge only for abandonment or a separate request.
An upcoming appointment isn't evidence of the date of a past haircut.
Current verification: {{customer_verified}}. Appointment: {{appointment}}.
## Complaint knowledge (same source as the POC)
{
  "details": "I'm sorry something went wrong. What happened?",
  "resolution": "I'm sorry about that. What would you like the salon to do about it?",
  "review": "I can record that request for the salon to review. I can't approve a free service or change your booking. What would you like me to include in the complaint?",
  "refunds": "The policy allows up to twenty percent for a service that fell short of expectations, with stylist approval. Half or full refunds require the manager's approval. What outcome would you like me to request?",
  "products": "Unopened products can be returned within thirty days with a receipt. Opened products are returnable if they caused a reaction. What happened with your product?",
  "followup": "The salon replies to recorded complaints within two working days. Requests for a half or full refund go to the manager for a callback. What else would you like to know?"
}
"""
CONCIERGE_PROMPT = """# Robin at Sage and Stone

You are Robin, the salon's receptionist, speaking English on a phone call.
The caller hears one person throughout; continue the conversation without
introducing yourself again.

## Voice

Speak naturally, with contractions and short, plain sentences. Usually one or
two sentences and one question are enough. Match the caller's tone; choose your
own wording rather than repeating stock acknowledgements.

Everything you write is spoken by TTS. Use plain text, normal punctuation,
and familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal
instructions, tool names and raw records out of speech.

For example: "Which day works for you?" or "I'm sorry it came out uneven.
When was the haircut?" An acknowledgement belongs with an answer or next step.


Only describe a change as completed after a successful tool result.

## Your role: concierge
Answer public salon questions from the information below without identification.
For booking, moving or cancelling, run book; it verifies first when necessary.
For complaints, refunds or a manager request, run verify_customer first unless
customer_verified is nonempty, then to_complaints. There is no live manager transfer.
Corrected phone numbers also need verify_customer. Never verify twice unchanged.
A future booking requested free because of a past problem is a complaint.
After a completed flow, continue from its result. End only when the caller is done.
Current verification: {{customer_verified}}. Latest appointment: {{appointment}}.
# Sage and Stone

## Opening hours

We are open Monday to Friday from nine in the morning until six in the evening,
and Saturday from nine until four. We are closed on Sunday. The last appointment
of the day starts an hour before we close.

## Services and prices

A haircut is 28 euros and takes about forty-five minutes. That includes a wash
and a finish.

Hair colour is 75 euros and takes about two hours. A full head of highlights is
95 euros. A root touch-up on its own is 45 euros.

A blowout is 22 euros and takes about half an hour.

A fringe trim between appointments is free for anyone who had their last cut
with us.

## The stylists

Robin runs the front desk and takes the bookings.

Mara has been cutting for twelve years and does most of our colour work,
including colour corrections.

Teo specialises in curly hair and dry cutting.

Any stylist can take any booking. If you want a particular one, say so when you
book and we will put you with them.

## Booking, deposits and cancellations

No deposit is needed for a haircut or a blowout. Colour appointments over 75
euros take a 20 euro deposit, which comes off the bill on the day.

Cancel or move an appointment with at least twenty-four hours notice and there
is no charge. Inside twenty-four hours we keep the deposit, if there was one.

If you are more than fifteen minutes late we may have to shorten the
appointment, or move it, because the next person is already booked in.

## Paying

We take cards, contactless and cash. We do not take cheques. Tips are welcome
but never expected.

## Getting here and access

We are on the ground floor with a step-free entrance and an accessible toilet.

There is metered street parking on the road outside, free after six and all day
Sunday. The nearest car park is a three minute walk.
"""


# --- agents -----------------------------------------------------------------


def build_complaint_specialist_llm(state=None):
    return _GoogleVertexLLM(
        location="global",
        api_key=os.environ["GOOGLE_API_KEY"],
        settings=GoogleLLMService.Settings(
            model="gemini-3.5-flash-lite",
            system_instruction=_render(
                COMPLAINT_SPECIALIST_PROMPT, state, site="agent:complaint_specialist"
            ),
            extra={
                "http_options": {
                    "headers": {"X-Vertex-AI-LLM-Shared-Request-Type": "priority"}
                }
            },
            thinking=GoogleLLMService.ThinkingConfig(**{"thinking_level": "MINIMAL"}),
        ),
    )


def build_complaint_specialist_tts():
    return SlngTTSService(
        api_key=os.environ["SLNG_API_KEY"],
        base_url="eu-north.api.slng.ai",
        voice="62ae83ad-4f6a-430b-af41-a9bede9286ca",
        model="cartesia/sonic:3.5",
        language=Language("en"),
        warm_standby_enabled=True,
        text_aggregation_mode="token",
    )


class ComplaintSpecialistAgent(TracedLLMWorker):
    """Agent: complaint_specialist."""

    def __init__(
        self, state=None, context=None, call_context=None, dev_metrics=None
    ) -> None:
        self.state = state
        if context is not None:
            self.context = context

        llm = build_complaint_specialist_llm(state)
        tts = build_complaint_specialist_tts()
        self._dev = dev_metrics
        if self._dev:
            self._dev.observe_llm(llm)
            self._dev.observe_tts(tts)
        super().__init__(
            "complaint_specialist", llm=llm, pipeline=Pipeline([llm, tts]), bridged=()
        )
        # Every tool the model called in one response, recorded before any of
        # their handlers run. A step that ends on its own tool has to know
        # whether a handoff was called beside it: this framework runs both
        # handlers and whichever finishes first would otherwise close the step
        # under the other one.
        self._response_calls: tuple[str, ...] = ()

        @llm.event_handler("on_function_calls_started")
        async def _record_calls(service, function_calls):  # noqa: ARG001
            self._response_calls = tuple(call.function_name for call in function_calls)

    async def queue_frame(self, frame, *args, **kwargs) -> None:
        if self._dev:
            self._dev.stamp(frame)
        await super().queue_frame(frame, *args, **kwargs)

    async def on_activated(self, args) -> None:
        token = self._dev.enter_activation(args) if self._dev else None
        try:
            await self.queue_frame(
                LLMUpdateSettingsFrame(
                    delta=LLMSettings(
                        system_instruction=_render(
                            COMPLAINT_SPECIALIST_PROMPT,
                            self.state,
                            site="agent:complaint_specialist",
                        )
                    ),
                )
            )
            await super().on_activated(args)
            # Pipecat 1.8 and 1.9 only run on activation when messages are nonempty.
            # A handoff already shaped the shared context; request the reply
            # without adding a synthetic message or waiting for the caller.
            if args and args.get("run_llm") and not args.get("messages"):
                await self.queue_frame(LLMRunFrame())
        finally:
            if self._dev:
                self._dev.exit_activation(token)

    def _bind_state(self, handler):
        """Give a module-level flows handler this worker's call state, so a task
        tool can read injected variables the same way an agent tool does."""

        async def _bound(args, flow_manager):
            return await handler(args, flow_manager, state=self.state)

        return _bound

    @_direct_tool(cancel_on_interruption=False)
    async def to_concierge(self, params: FunctionCallParams):
        """The caller changes to a request owned by another specialist."""
        # context.history on this handoff. One LLMContext is shared for the whole
        # call, so the receiver is given the shaped list rather than a copy.
        self.context.set_messages(_speech_only(self.context.get_messages()))
        await self.activate_worker(
            "concierge",
            args=LLMWorkerActivationArgs(
                metadata=self._dev.activation_metadata() if self._dev else None,
                messages=[],
                run_llm=True,
            ),
            deactivate_self=True,
            result_callback=params.result_callback,
        )

    @_direct_tool(announce="I'll record that complaint.")
    async def record_complaint(
        self, params: FunctionCallParams, requested_resolution: str, summary: str
    ):
        """Record once, after the caller approves the complaint and resolution readback. Preserve that wording exactly; this does not approve the requested remedy.

        Args:
            requested_resolution (str): What the customer wants the salon to do, or an empty string
            summary (str): Short factual summary of the complaint
        """
        state = self.state
        refusal = _refusal(
            "record_complaint",
            state,
            [("customer_phone", "run verify_customer first.")],
        )
        if refusal:
            await params.result_callback({"refused": refusal})
            return
        result = tools.record_complaint.record_complaint(
            requested_resolution=requested_resolution,
            summary=summary,
            customer_phone=state.customer_phone,
        )
        if inspect.isawaitable(result):
            result = await result
        await params.result_callback(result)

    @_direct_tool
    async def end_call(self, params: FunctionCallParams):
        """End the call once the caller's own words say the call is over: "no, that's all", "I'm good, thanks", "goodbye". A question is never one of those, however tired it sounds. On a live call on 2026-09-16 the caller asked "can we just recap when I have the next appointment?" and this ended the call on them. Answer what they asked and wait for them to say they are done."""
        await params.llm.push_frame(
            LLMMessagesAppendFrame(
                [
                    {
                        "role": "developer",
                        "content": "Say one short goodbye in your own words, then end the call. Do not offer anything else first.",
                    }
                ],
                run_llm=False,
            )
        )
        await params.result_callback({"ended": True})
        await params.pipeline_worker.end()

    @_direct_tool
    async def verify_customer(self, params: FunctionCallParams):
        """Before a complaint if not verified, or after a phone correction. The caller's words right above the status are what the step answered; it served the part it owns, so act only on what remains."""
        # Already ran, and nobody has spoken since. Then this is not a second
        # request, it is the model reading its own completed result as though it
        # were one. On a live call on 2026-09-16 (trace 917975e9, LiveKit, same
        # package) a booking saved, the flow re-entered on the caller's own
        # "3 o'clock" still sitting above the result, and the last thing the
        # caller heard was an agent saying it was off to check the diary.
        #
        # Refused here rather than asked for in the prompt, which this package
        # did twice and which failed twice. Before the announcement below, so a
        # refused call speaks nothing at all.
        if _caller_turns(self.context.get_messages()) == getattr(
            self, "_ran_at_verify_customer", None
        ):
            await params.result_callback(
                {
                    "refused": "This already ran and finished, and the caller has "
                    "not spoken since, so its result is the answer to what they "
                    "asked. Reply to them from the values in your prompt. Run it "
                    "again only once they have asked for something new."
                }
            )
            return
        # Cover the entry: two model requests pass between the caller finishing and
        # the step's first word, and this puts speech in them. TTSSpeakFrame is a
        # DataFrame, so it is queued and speech starts while the flow is built.
        # Queued at the very start of the method, before anything else runs.
        await self.queue_frame(TTSSpeakFrame("Let me confirm who I'm speaking to."))
        self._verify_customer_visit = object()
        self._verify_customer_results = {}
        # Per invocation: the tool that ended a step and what it returned, an
        # event a sibling handoff waits on, and the caller turn the step
        # consumed on its way out.
        self._verify_customer_terminal = None
        self._verify_customer_pending = False
        self._verify_customer_settled = asyncio.Event()
        self._verify_customer_carried_turn = None
        self._verify_customer_active_step = "verify_customer"
        flow = FlowManager(
            llm=self.llm,
            context_aggregator=LLMContextAggregatorPair(self.context),
            worker=self,
        )
        # Resolve this tool call so it never dangles (V3/B1), but with
        # run_llm=False: the flow's first node (respond_immediately) is the sole
        # responder, so the owner never runs a second completion and the caller
        # hears the task's opening line once, not twice (V7/B4).
        await params.result_callback(
            {"status": "running the verify_customer task"},
            properties=FunctionCallResultProperties(run_llm=False),
        )
        # V2/B2: drain the resolved owner call before snapshotting. Otherwise
        # restoration erases that call and the unchanged request delegates again.
        await self.flush_pipeline()
        self._verify_customer_snapshot = (
            copy.deepcopy(self.context.get_messages()),
            self.context.tools,
        )
        # How many caller turns the owner has seen, so a step that ends on its
        # tool can tell whether the turn it consumed is one the owner never saw.
        self._verify_customer_snapshot_turns = _caller_turns(
            self.context.get_messages()
        )
        # context.history on this task. Shaped after the snapshot above, so the
        # finish path restores the owner's own context whatever this step saw.
        self.context.set_messages(_speech_only(self.context.get_messages()))
        await flow.initialize(await self._verify_customer_node_verify_customer())

    def _verify_customer_settle(self):
        """The running mutation is over, one way or another."""
        self._verify_customer_pending = False
        self._verify_customer_settled.set()

    async def _verify_customer_node_verify_customer(self) -> NodeConfig:
        # This step's own ending, whatever the step before it did. Held on the
        # flow rather than the step, so the tool that ended the previous step
        # closed this one's mutations too: a verified caller was told their
        # first booking had already succeeded.
        self._verify_customer_terminal = None
        self._verify_customer_pending = False
        self._verify_customer_settled.clear()
        self._verify_customer_carried_turn = None
        # Entered, so whatever it confirms is being decided again. Withdrawn
        # before role_message renders, so this step never reads a confirmation
        # it is about to replace.
        _withdraw_confirmation(self.state, "verify_customer")
        self.context.set_messages(_speech_only(self.context.get_messages()))
        return NodeConfig(
            name="verify_customer",
            role_message=_render(
                '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Verify the customer\nCombine phone fragments. Ask only for missing digits or country information.\nAccept valid Spanish numbers in full international form, +34 and nine digits.\nIf the country is missing, ask; never infer it. Read every digit back, then wait for yes.\nWhen a saved number is present, read it back in the first question instead of asking\nfor a number again. Include the country code. Never drop or change digits.\nA correction needs another readback. Giving digits or asking a question isn\'t yes.\nOnly after approval, call find_or_create_customer with the confirmed number.\nThat tool finishes verification; the pending request continues without a new greeting.\nIf the caller declines or changes subject, finish with the unserved request.\nSaved number: {{customer_phone}}. Status: {{customer_verified}}.\n\n\nWhen this step is complete, call `finish_verify_customer_verify_customer` with: customer_phone, customer_status.\n\nWhen `find_or_create_customer` returns a successful result, this step ends by itself and saves it; do not call `finish_verify_customer_verify_customer` after it. `finish_verify_customer_verify_customer` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_verify_customer_verify_customer` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                self.state,
                site="task:verify_customer",
            ),
            task_messages=[{"role": "developer", "content": "Begin this step."}],
            functions=[
                FlowsFunctionSchema(
                    name="find_or_create_customer",
                    description="Look up or create one salon customer from the exact confirmed phone number. Use only after the digit readback got a clear yes. Reuse the record that already owns the number, or create one for a number that is new. Never guess a number or pass one the caller has not confirmed. A caller giving a replacement number is not confirmation. Ask the readback question first; call this tool only after a later caller message agrees to it.",
                    properties={
                        "phone": {
                            "description": "The approved Spanish number in full international form, +34 followed by nine digits. Never infer country or approval.",
                            "type": "string",
                        }
                    },
                    required=["phone"],
                    handler=_flow_visit(
                        self,
                        "verify_customer",
                        self._trace_flow_tool(
                            "find_or_create_customer",
                            self._verify_customer_terminal_verify_customer_find_or_create_customer,
                        ),
                    ),
                ),
                FlowsFunctionSchema(
                    name="finish_verify_customer_verify_customer",
                    description="Record the result of this step and finish.",
                    properties={
                        "unserved_request": {
                            "description": "Leave empty unless the caller asked for something this step cannot serve. Then put that request here in one short plain sentence, in the caller's own terms, so the agent that owns this step can take it.",
                            "type": "string",
                        },
                        "customer_phone": _schema(
                            TypeAdapter(
                                Annotated[
                                    Phone | None,
                                    Field(
                                        description="The caller's phone number in E.164: a plus sign, then digits, with no spaces, brackets or dashes. One shape for every phone number in this package, the MANAGER_PHONE_NUMBER transfer destination included, so no prompt and no tool has to guess which shape it is holding.\nNo `source:` here on purpose. The prefetch block below reads the carrier's fact and this variable receives it, which leaves the per-route refusal for a variable naming a source its target cannot supply exactly as strict as it is: on a route with no caller ID the entry skips and this holds its default.\nOffered to the caller for a yes, never acted on unasked. Somebody may be ringing from a friend's phone, or may hold a second account, so until the verification step has heard them agree this value stays unconfirmed and appears in no prompt but that step's own."
                                    ),
                                ]
                            )
                        ),
                        "customer_status": _schema(
                            TypeAdapter(
                                Annotated[
                                    str | None,
                                    Field(
                                        description="Whether verification has already run on this call, and what it found. Set by the verification step as it ends, which only happens on a number the caller agreed to, so a value here means the number beside it is confirmed.\nIt exists for customer care, which has to decide whether to identify the caller before writing a complaint down and cannot read `customer_phone` to find out: an unconfirmed number renders in no prompt but the verification step's own, and a confirmed one must not be in front of an agent that might say it out loud. This carries the same fact with nothing sensitive in it.\nThe concierge does not read it. The `book` flow decides the same thing structurally with `skip_when_confirmed:`, off the confirmation itself rather than off a copy of it.\nEmpty means nobody has been verified yet on this call."
                                    ),
                                ]
                            )
                        ),
                    },
                    required=[],
                    handler=_flow_visit(
                        self,
                        "verify_customer",
                        self._trace_flow_tool(
                            "finish_verify_customer_verify_customer",
                            self._verify_customer_finish_verify_customer,
                        ),
                    ),
                ),
            ],
        )

    async def _verify_customer_terminal_verify_customer_find_or_create_customer(
        self, args, flow_manager
    ):
        """Run find_or_create_customer and end this step when it says it did the work.

        The result never reaches the model on a success: the tool has already
        made the decision the model would have been asked to confirm. Anything
        else goes back as an ordinary result and the step stays open.
        """
        if self._verify_customer_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._verify_customer_terminal is not None:
            logger.info(
                "terminal tool refused: find_or_create_customer cannot run again in this step"
            )
            return {
                "refused": "find_or_create_customer already succeeded in this step. Call finish to record it; a new action is a new request from the caller."
            }, None
        # In flight from here until settled, whichever response called it: a
        # handoff or a finish arriving while it runs waits for it rather than
        # moving the caller past an action nobody recorded.
        _visit = self._verify_customer_visit
        self._verify_customer_pending = True
        self._verify_customer_settled.clear()
        try:
            result = await _flow_tool_find_or_create_customer(args, flow_manager)
        except BaseException:
            self._verify_customer_settle()
            raise
        if (
            self._verify_customer_visit is not _visit
            or self._verify_customer_active_step != "verify_customer"
        ):
            # The flow moved while the tool ran. Nothing here may write state
            # a later step now owns, so the result goes back as it is.
            self._verify_customer_settle()
            return result, None
        if not _terminal_success(
            result,
            {
                "customer_status": (
                    "existing",
                    "created",
                )
            },
        ):
            # A failed action has nothing to save, and it still settles: a
            # handoff waiting beside it stops waiting and leaves the caller here.
            self._verify_customer_settle()
            return result, None
        self._verify_customer_terminal = ("find_or_create_customer", result)
        _messages = self.context.get_messages()
        if _caller_turns(_messages) > self._verify_customer_snapshot_turns:
            # The turn this call answered arrived after the owner's snapshot, so
            # the owner never saw it. Counted rather than matched on its text,
            # because a caller who says the same word twice has said it twice.
            self._verify_customer_carried_turn = _newest_caller_message(_messages)
        try:
            _values = _save_result("verify_customer", self.state, result)
        except _StateRefused as refused:
            # The action happened and the save did not. The step stays open so
            # the model can repair it, and its mutations stay closed so the
            # repair cannot run the action a second time.
            self._verify_customer_settle()
            logger.warning(
                "terminal find_or_create_customer: not recorded: " + refused.message
            )
            return {
                **result,
                "refused": "Not recorded: "
                + refused.message
                + ". Call finish with the values this tool returned; recover a missing one with a read tool of this step, or finish with unserved_request saying the action happened and its details could not be saved.",
            }, None
        self._verify_customer_settle()
        logger.info("step verify_customer ended on find_or_create_customer")
        # Saved once, above. The advance is the finish handler's own tail,
        # shared rather than copied, and it saves nothing itself: a second save
        # wrote a second entry onto every list an assign appends to.
        return await self._verify_customer_advance_verify_customer(_values)

    async def _verify_customer_finish_verify_customer(self, args, flow_manager):
        if self._verify_customer_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._verify_customer_pending:
            # A tool that ends this step is still running, and its result
            # decides the step. Wait for it rather than ending the step under it
            # and leaving what it did unrecorded.
            try:
                await asyncio.wait_for(
                    self._verify_customer_settled.wait(), timeout=30.0
                )
            except asyncio.TimeoutError:
                self._verify_customer_settle()
            if self._verify_customer_active_step != "verify_customer":
                return {"status": "already handled"}, NO_RESPONSE
        args = dict(args)
        if self._verify_customer_terminal is not None:
            # Repairing a save the tool already made. The tool's own values win
            # where they validate: the model cannot manufacture a reference, and
            # a repair that retyped one would record an action nobody took.
            args = _merge_retained(
                "verify_customer", args, self._verify_customer_terminal[1]
            )
        # Validated before anything is recorded: a value that does not fit its
        # declared type never enters the state, the previous contents stand, and
        # the message goes back to the model so it can correct itself on the next
        # turn instead of the step recording something wrong. This framework
        # validates no tool argument itself, so without this the two targets
        # would behave differently on the same package.
        try:
            _values = _save_result("verify_customer", self.state, dict(args))
        except _StateRefused as refused:
            logger.warning("finish {}: {}", "verify_customer", refused.message)
            return {
                "refused": f"Not recorded: {refused.message}. Ask again, then call finish with a value that fits."
            }, None
        return await self._verify_customer_advance_verify_customer(_values)

    async def _verify_customer_advance_verify_customer(self, _values):
        """Move the flow on with this step's saved values: the next step, the owner, or the end."""
        self._verify_customer_results["verify_customer"] = _values
        self._verify_customer_active_step = None
        # then: return — restore the owner's pre-flow context (messages and
        # tools); only a completed or unserved status crosses back.
        messages, tools = self._verify_customer_snapshot
        _settle_task_call(
            messages, "verify_customer", _group_status(self._verify_customer_results)
        )
        await self.queue_frame(
            LLMUpdateSettingsFrame(
                delta=LLMSettings(
                    system_instruction=_render(
                        COMPLAINT_SPECIALIST_PROMPT,
                        self.state,
                        site="agent:complaint_specialist",
                    )
                ),
            )
        )
        await self.flush_pipeline()
        self.context.set_messages(
            messages
            + _carried_messages(self._verify_customer_carried_turn)
            + [
                {
                    "role": "developer",
                    "content": json.dumps(_group_status(self._verify_customer_results)),
                }
            ]
        )
        self.context.set_tools(tools)
        # Counted after the restore, so a turn a step consumed and carried back
        # is included: that turn is the one the owner is about to read, and it
        # is exactly the turn that must not be mistaken for a new request.
        self._ran_at_verify_customer = _caller_turns(self.context.get_messages())
        return {"status": "ok"}, None


def build_concierge_llm(state=None):
    return _GoogleVertexLLM(
        location="global",
        api_key=os.environ["GOOGLE_API_KEY"],
        settings=GoogleLLMService.Settings(
            model="gemini-3.5-flash-lite",
            system_instruction=_render(CONCIERGE_PROMPT, state, site="agent:concierge"),
            extra={
                "http_options": {
                    "headers": {"X-Vertex-AI-LLM-Shared-Request-Type": "priority"}
                }
            },
            thinking=GoogleLLMService.ThinkingConfig(**{"thinking_level": "MINIMAL"}),
        ),
    )


def build_concierge_tts():
    return SlngTTSService(
        api_key=os.environ["SLNG_API_KEY"],
        base_url="eu-north.api.slng.ai",
        voice="62ae83ad-4f6a-430b-af41-a9bede9286ca",
        model="cartesia/sonic:3.5",
        language=Language("en"),
        warm_standby_enabled=True,
        text_aggregation_mode="token",
    )


class ConciergeAgent(TracedLLMWorker):
    """Agent: concierge."""

    def __init__(
        self, state=None, context=None, call_context=None, dev_metrics=None
    ) -> None:
        self.state = state
        if context is not None:
            self.context = context

        llm = build_concierge_llm(state)
        tts = build_concierge_tts()
        self._dev = dev_metrics
        if self._dev:
            self._dev.observe_llm(llm)
            self._dev.observe_tts(tts)
        super().__init__(
            "concierge", llm=llm, pipeline=Pipeline([llm, tts]), bridged=()
        )
        # Every tool the model called in one response, recorded before any of
        # their handlers run. A step that ends on its own tool has to know
        # whether a handoff was called beside it: this framework runs both
        # handlers and whichever finishes first would otherwise close the step
        # under the other one.
        self._response_calls: tuple[str, ...] = ()

        @llm.event_handler("on_function_calls_started")
        async def _record_calls(service, function_calls):  # noqa: ARG001
            self._response_calls = tuple(call.function_name for call in function_calls)

    async def queue_frame(self, frame, *args, **kwargs) -> None:
        if self._dev:
            self._dev.stamp(frame)
        await super().queue_frame(frame, *args, **kwargs)

    async def on_activated(self, args) -> None:
        token = self._dev.enter_activation(args) if self._dev else None
        try:
            await self.queue_frame(
                LLMUpdateSettingsFrame(
                    delta=LLMSettings(
                        system_instruction=_render(
                            CONCIERGE_PROMPT, self.state, site="agent:concierge"
                        )
                    ),
                )
            )
            await super().on_activated(args)
            # Pipecat 1.8 and 1.9 only run on activation when messages are nonempty.
            # A handoff already shaped the shared context; request the reply
            # without adding a synthetic message or waiting for the caller.
            if args and args.get("run_llm") and not args.get("messages"):
                await self.queue_frame(LLMRunFrame())
        finally:
            if self._dev:
                self._dev.exit_activation(token)

    def _bind_state(self, handler):
        """Give a module-level flows handler this worker's call state, so a task
        tool can read injected variables the same way an agent tool does."""

        async def _bound(args, flow_manager):
            return await handler(args, flow_manager, state=self.state)

        return _bound

    @_direct_tool(cancel_on_interruption=False)
    async def to_complaints(self, params: FunctionCallParams):
        """The caller has a complaint or service problem."""
        # context.history on this handoff. One LLMContext is shared for the whole
        # call, so the receiver is given the shaped list rather than a copy.
        self.context.set_messages(_speech_only(self.context.get_messages()))
        await self.activate_worker(
            "complaint_specialist",
            args=LLMWorkerActivationArgs(
                metadata=self._dev.activation_metadata() if self._dev else None,
                messages=[],
                run_llm=True,
            ),
            deactivate_self=True,
            result_callback=params.result_callback,
        )

    @_direct_tool
    async def end_call(self, params: FunctionCallParams):
        """End the call once the caller's own words say the call is over: "no, that's all", "I'm good, thanks", "goodbye". A question is never one of those, however tired it sounds. On a live call on 2026-09-16 the caller asked "can we just recap when I have the next appointment?" and this ended the call on them. Answer what they asked and wait for them to say they are done."""
        await params.llm.push_frame(
            LLMMessagesAppendFrame(
                [
                    {
                        "role": "developer",
                        "content": "Say one short goodbye in your own words, then end the call. Do not offer anything else first.",
                    }
                ],
                run_llm=False,
            )
        )
        await params.result_callback({"ended": True})
        await params.pipeline_worker.end()

    @_direct_tool
    async def verify_customer(self, params: FunctionCallParams):
        """Before a complaint if not verified, or after a phone correction. The caller's words right above the status are what the step answered; it served the part it owns, so act only on what remains."""
        # Already ran, and nobody has spoken since. Then this is not a second
        # request, it is the model reading its own completed result as though it
        # were one. On a live call on 2026-09-16 (trace 917975e9, LiveKit, same
        # package) a booking saved, the flow re-entered on the caller's own
        # "3 o'clock" still sitting above the result, and the last thing the
        # caller heard was an agent saying it was off to check the diary.
        #
        # Refused here rather than asked for in the prompt, which this package
        # did twice and which failed twice. Before the announcement below, so a
        # refused call speaks nothing at all.
        if _caller_turns(self.context.get_messages()) == getattr(
            self, "_ran_at_verify_customer", None
        ):
            await params.result_callback(
                {
                    "refused": "This already ran and finished, and the caller has "
                    "not spoken since, so its result is the answer to what they "
                    "asked. Reply to them from the values in your prompt. Run it "
                    "again only once they have asked for something new."
                }
            )
            return
        # Cover the entry: two model requests pass between the caller finishing and
        # the step's first word, and this puts speech in them. TTSSpeakFrame is a
        # DataFrame, so it is queued and speech starts while the flow is built.
        # Queued at the very start of the method, before anything else runs.
        await self.queue_frame(TTSSpeakFrame("Let me confirm who I'm speaking to."))
        self._verify_customer_visit = object()
        self._verify_customer_results = {}
        # Per invocation: the tool that ended a step and what it returned, an
        # event a sibling handoff waits on, and the caller turn the step
        # consumed on its way out.
        self._verify_customer_terminal = None
        self._verify_customer_pending = False
        self._verify_customer_settled = asyncio.Event()
        self._verify_customer_carried_turn = None
        self._verify_customer_active_step = "verify_customer"
        flow = FlowManager(
            llm=self.llm,
            context_aggregator=LLMContextAggregatorPair(self.context),
            worker=self,
        )
        # Resolve this tool call so it never dangles (V3/B1), but with
        # run_llm=False: the flow's first node (respond_immediately) is the sole
        # responder, so the owner never runs a second completion and the caller
        # hears the task's opening line once, not twice (V7/B4).
        await params.result_callback(
            {"status": "running the verify_customer task"},
            properties=FunctionCallResultProperties(run_llm=False),
        )
        # V2/B2: drain the resolved owner call before snapshotting. Otherwise
        # restoration erases that call and the unchanged request delegates again.
        await self.flush_pipeline()
        self._verify_customer_snapshot = (
            copy.deepcopy(self.context.get_messages()),
            self.context.tools,
        )
        # How many caller turns the owner has seen, so a step that ends on its
        # tool can tell whether the turn it consumed is one the owner never saw.
        self._verify_customer_snapshot_turns = _caller_turns(
            self.context.get_messages()
        )
        # context.history on this task. Shaped after the snapshot above, so the
        # finish path restores the owner's own context whatever this step saw.
        self.context.set_messages(_speech_only(self.context.get_messages()))
        await flow.initialize(await self._verify_customer_node_verify_customer())

    def _verify_customer_settle(self):
        """The running mutation is over, one way or another."""
        self._verify_customer_pending = False
        self._verify_customer_settled.set()

    async def _verify_customer_node_verify_customer(self) -> NodeConfig:
        # This step's own ending, whatever the step before it did. Held on the
        # flow rather than the step, so the tool that ended the previous step
        # closed this one's mutations too: a verified caller was told their
        # first booking had already succeeded.
        self._verify_customer_terminal = None
        self._verify_customer_pending = False
        self._verify_customer_settled.clear()
        self._verify_customer_carried_turn = None
        # Entered, so whatever it confirms is being decided again. Withdrawn
        # before role_message renders, so this step never reads a confirmation
        # it is about to replace.
        _withdraw_confirmation(self.state, "verify_customer")
        self.context.set_messages(_speech_only(self.context.get_messages()))
        return NodeConfig(
            name="verify_customer",
            role_message=_render(
                '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Verify the customer\nCombine phone fragments. Ask only for missing digits or country information.\nAccept valid Spanish numbers in full international form, +34 and nine digits.\nIf the country is missing, ask; never infer it. Read every digit back, then wait for yes.\nWhen a saved number is present, read it back in the first question instead of asking\nfor a number again. Include the country code. Never drop or change digits.\nA correction needs another readback. Giving digits or asking a question isn\'t yes.\nOnly after approval, call find_or_create_customer with the confirmed number.\nThat tool finishes verification; the pending request continues without a new greeting.\nIf the caller declines or changes subject, finish with the unserved request.\nSaved number: {{customer_phone}}. Status: {{customer_verified}}.\n\n\nWhen this step is complete, call `finish_verify_customer_verify_customer` with: customer_phone, customer_status.\n\nWhen `find_or_create_customer` returns a successful result, this step ends by itself and saves it; do not call `finish_verify_customer_verify_customer` after it. `finish_verify_customer_verify_customer` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_verify_customer_verify_customer` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                self.state,
                site="task:verify_customer",
            ),
            task_messages=[{"role": "developer", "content": "Begin this step."}],
            functions=[
                FlowsFunctionSchema(
                    name="find_or_create_customer",
                    description="Look up or create one salon customer from the exact confirmed phone number. Use only after the digit readback got a clear yes. Reuse the record that already owns the number, or create one for a number that is new. Never guess a number or pass one the caller has not confirmed. A caller giving a replacement number is not confirmation. Ask the readback question first; call this tool only after a later caller message agrees to it.",
                    properties={
                        "phone": {
                            "description": "The approved Spanish number in full international form, +34 followed by nine digits. Never infer country or approval.",
                            "type": "string",
                        }
                    },
                    required=["phone"],
                    handler=_flow_visit(
                        self,
                        "verify_customer",
                        self._trace_flow_tool(
                            "find_or_create_customer",
                            self._verify_customer_terminal_verify_customer_find_or_create_customer,
                        ),
                    ),
                ),
                FlowsFunctionSchema(
                    name="finish_verify_customer_verify_customer",
                    description="Record the result of this step and finish.",
                    properties={
                        "unserved_request": {
                            "description": "Leave empty unless the caller asked for something this step cannot serve. Then put that request here in one short plain sentence, in the caller's own terms, so the agent that owns this step can take it.",
                            "type": "string",
                        },
                        "customer_phone": _schema(
                            TypeAdapter(
                                Annotated[
                                    Phone | None,
                                    Field(
                                        description="The caller's phone number in E.164: a plus sign, then digits, with no spaces, brackets or dashes. One shape for every phone number in this package, the MANAGER_PHONE_NUMBER transfer destination included, so no prompt and no tool has to guess which shape it is holding.\nNo `source:` here on purpose. The prefetch block below reads the carrier's fact and this variable receives it, which leaves the per-route refusal for a variable naming a source its target cannot supply exactly as strict as it is: on a route with no caller ID the entry skips and this holds its default.\nOffered to the caller for a yes, never acted on unasked. Somebody may be ringing from a friend's phone, or may hold a second account, so until the verification step has heard them agree this value stays unconfirmed and appears in no prompt but that step's own."
                                    ),
                                ]
                            )
                        ),
                        "customer_status": _schema(
                            TypeAdapter(
                                Annotated[
                                    str | None,
                                    Field(
                                        description="Whether verification has already run on this call, and what it found. Set by the verification step as it ends, which only happens on a number the caller agreed to, so a value here means the number beside it is confirmed.\nIt exists for customer care, which has to decide whether to identify the caller before writing a complaint down and cannot read `customer_phone` to find out: an unconfirmed number renders in no prompt but the verification step's own, and a confirmed one must not be in front of an agent that might say it out loud. This carries the same fact with nothing sensitive in it.\nThe concierge does not read it. The `book` flow decides the same thing structurally with `skip_when_confirmed:`, off the confirmation itself rather than off a copy of it.\nEmpty means nobody has been verified yet on this call."
                                    ),
                                ]
                            )
                        ),
                    },
                    required=[],
                    handler=_flow_visit(
                        self,
                        "verify_customer",
                        self._trace_flow_tool(
                            "finish_verify_customer_verify_customer",
                            self._verify_customer_finish_verify_customer,
                        ),
                    ),
                ),
            ],
        )

    async def _verify_customer_terminal_verify_customer_find_or_create_customer(
        self, args, flow_manager
    ):
        """Run find_or_create_customer and end this step when it says it did the work.

        The result never reaches the model on a success: the tool has already
        made the decision the model would have been asked to confirm. Anything
        else goes back as an ordinary result and the step stays open.
        """
        if self._verify_customer_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._verify_customer_terminal is not None:
            logger.info(
                "terminal tool refused: find_or_create_customer cannot run again in this step"
            )
            return {
                "refused": "find_or_create_customer already succeeded in this step. Call finish to record it; a new action is a new request from the caller."
            }, None
        # In flight from here until settled, whichever response called it: a
        # handoff or a finish arriving while it runs waits for it rather than
        # moving the caller past an action nobody recorded.
        _visit = self._verify_customer_visit
        self._verify_customer_pending = True
        self._verify_customer_settled.clear()
        try:
            result = await _flow_tool_find_or_create_customer(args, flow_manager)
        except BaseException:
            self._verify_customer_settle()
            raise
        if (
            self._verify_customer_visit is not _visit
            or self._verify_customer_active_step != "verify_customer"
        ):
            # The flow moved while the tool ran. Nothing here may write state
            # a later step now owns, so the result goes back as it is.
            self._verify_customer_settle()
            return result, None
        if not _terminal_success(
            result,
            {
                "customer_status": (
                    "existing",
                    "created",
                )
            },
        ):
            # A failed action has nothing to save, and it still settles: a
            # handoff waiting beside it stops waiting and leaves the caller here.
            self._verify_customer_settle()
            return result, None
        self._verify_customer_terminal = ("find_or_create_customer", result)
        _messages = self.context.get_messages()
        if _caller_turns(_messages) > self._verify_customer_snapshot_turns:
            # The turn this call answered arrived after the owner's snapshot, so
            # the owner never saw it. Counted rather than matched on its text,
            # because a caller who says the same word twice has said it twice.
            self._verify_customer_carried_turn = _newest_caller_message(_messages)
        try:
            _values = _save_result("verify_customer", self.state, result)
        except _StateRefused as refused:
            # The action happened and the save did not. The step stays open so
            # the model can repair it, and its mutations stay closed so the
            # repair cannot run the action a second time.
            self._verify_customer_settle()
            logger.warning(
                "terminal find_or_create_customer: not recorded: " + refused.message
            )
            return {
                **result,
                "refused": "Not recorded: "
                + refused.message
                + ". Call finish with the values this tool returned; recover a missing one with a read tool of this step, or finish with unserved_request saying the action happened and its details could not be saved.",
            }, None
        self._verify_customer_settle()
        logger.info("step verify_customer ended on find_or_create_customer")
        # Saved once, above. The advance is the finish handler's own tail,
        # shared rather than copied, and it saves nothing itself: a second save
        # wrote a second entry onto every list an assign appends to.
        return await self._verify_customer_advance_verify_customer(_values)

    async def _verify_customer_finish_verify_customer(self, args, flow_manager):
        if self._verify_customer_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._verify_customer_pending:
            # A tool that ends this step is still running, and its result
            # decides the step. Wait for it rather than ending the step under it
            # and leaving what it did unrecorded.
            try:
                await asyncio.wait_for(
                    self._verify_customer_settled.wait(), timeout=30.0
                )
            except asyncio.TimeoutError:
                self._verify_customer_settle()
            if self._verify_customer_active_step != "verify_customer":
                return {"status": "already handled"}, NO_RESPONSE
        args = dict(args)
        if self._verify_customer_terminal is not None:
            # Repairing a save the tool already made. The tool's own values win
            # where they validate: the model cannot manufacture a reference, and
            # a repair that retyped one would record an action nobody took.
            args = _merge_retained(
                "verify_customer", args, self._verify_customer_terminal[1]
            )
        # Validated before anything is recorded: a value that does not fit its
        # declared type never enters the state, the previous contents stand, and
        # the message goes back to the model so it can correct itself on the next
        # turn instead of the step recording something wrong. This framework
        # validates no tool argument itself, so without this the two targets
        # would behave differently on the same package.
        try:
            _values = _save_result("verify_customer", self.state, dict(args))
        except _StateRefused as refused:
            logger.warning("finish {}: {}", "verify_customer", refused.message)
            return {
                "refused": f"Not recorded: {refused.message}. Ask again, then call finish with a value that fits."
            }, None
        return await self._verify_customer_advance_verify_customer(_values)

    async def _verify_customer_advance_verify_customer(self, _values):
        """Move the flow on with this step's saved values: the next step, the owner, or the end."""
        self._verify_customer_results["verify_customer"] = _values
        self._verify_customer_active_step = None
        # then: return — restore the owner's pre-flow context (messages and
        # tools); only a completed or unserved status crosses back.
        messages, tools = self._verify_customer_snapshot
        _settle_task_call(
            messages, "verify_customer", _group_status(self._verify_customer_results)
        )
        await self.queue_frame(
            LLMUpdateSettingsFrame(
                delta=LLMSettings(
                    system_instruction=_render(
                        CONCIERGE_PROMPT, self.state, site="agent:concierge"
                    )
                ),
            )
        )
        await self.flush_pipeline()
        self.context.set_messages(
            messages
            + _carried_messages(self._verify_customer_carried_turn)
            + [
                {
                    "role": "developer",
                    "content": json.dumps(_group_status(self._verify_customer_results)),
                }
            ]
        )
        self.context.set_tools(tools)
        # Counted after the restore, so a turn a step consumed and carried back
        # is included: that turn is the one the owner is about to read, and it
        # is exactly the turn that must not be mistaken for a new request.
        self._ran_at_verify_customer = _caller_turns(self.context.get_messages())
        return {"status": "ok"}, None

    @_direct_tool
    async def book(self, params: FunctionCallParams):
        """The caller wants to create, move or cancel a booking. Includes a change to an appointment just made. The caller's words right above the status are what the step answered; it served the part it owns, so act only on what remains."""
        # Already ran, and nobody has spoken since. Then this is not a second
        # request, it is the model reading its own completed result as though it
        # were one. On a live call on 2026-09-16 (trace 917975e9, LiveKit, same
        # package) a booking saved, the flow re-entered on the caller's own
        # "3 o'clock" still sitting above the result, and the last thing the
        # caller heard was an agent saying it was off to check the diary.
        #
        # Refused here rather than asked for in the prompt, which this package
        # did twice and which failed twice. Before the announcement below, so a
        # refused call speaks nothing at all.
        if _caller_turns(self.context.get_messages()) == getattr(
            self, "_ran_at_book", None
        ):
            await params.result_callback(
                {
                    "refused": "This already ran and finished, and the caller has "
                    "not spoken since, so its result is the answer to what they "
                    "asked. Reply to them from the values in your prompt. Run it "
                    "again only once they have asked for something new."
                }
            )
            return
        self._book_visit = object()
        self._book_results = {}
        # Per invocation: the tool that ended a step and what it returned, an
        # event a sibling handoff waits on, and the caller turn the step
        # consumed on its way out.
        self._book_terminal = None
        self._book_pending = False
        self._book_settled = asyncio.Event()
        self._book_carried_turn = None
        # The steps this invocation will run, decided once as the flow starts.
        # A step whose confirmation already holds is not entered at all.
        self._book_plan = [
            name
            for name, confirmed in (
                ("verify_customer", "customer_phone"),
                ("manage_booking", ""),
            )
            if not (confirmed and _is_confirmed(self.state, confirmed))
        ]

        self._book_active_step = self._book_plan[0]
        flow = FlowManager(
            llm=self.llm,
            context_aggregator=LLMContextAggregatorPair(self.context),
            worker=self,
        )
        # Resolve this tool call so it never dangles (V3/B1), but with
        # run_llm=False: the flow's first node (respond_immediately) is the sole
        # responder, so the owner never runs a second completion and the caller
        # hears the task's opening line once, not twice (V7/B4).
        await params.result_callback(
            {"status": "running the book flow"},
            properties=FunctionCallResultProperties(run_llm=False),
        )
        # V2/B2: drain the resolved owner call before snapshotting. Otherwise
        # restoration erases that call and the unchanged request delegates again.
        await self.flush_pipeline()
        self._book_snapshot = (
            copy.deepcopy(self.context.get_messages()),
            self.context.tools,
        )
        # How many caller turns the owner has seen, so a step that ends on its
        # tool can tell whether the turn it consumed is one the owner never saw.
        self._book_snapshot_turns = _caller_turns(self.context.get_messages())
        # context.history on this task. Shaped after the snapshot above, so the
        # finish path restores the owner's own context whatever this step saw.
        self.context.set_messages(_speech_only(self.context.get_messages()))
        await flow.initialize(await self._book_node(self._book_active_step))

    async def _book_node(self, name) -> NodeConfig:
        """One step's node by name, because the chain is decided at run time."""
        return await {
            "verify_customer": self._book_node_verify_customer,
            "manage_booking": self._book_node_manage_booking,
        }[name]()

    def _book_next(self, name):
        """The step after this one in this invocation's plan, or None."""
        plan = self._book_plan
        position = plan.index(name) + 1
        return plan[position] if position < len(plan) else None

    def _book_settle(self):
        """The running mutation is over, one way or another."""
        self._book_pending = False
        self._book_settled.set()

    async def _book_node_verify_customer(self) -> NodeConfig:
        # This step's own ending, whatever the step before it did. Held on the
        # flow rather than the step, so the tool that ended the previous step
        # closed this one's mutations too: a verified caller was told their
        # first booking had already succeeded.
        self._book_terminal = None
        self._book_pending = False
        self._book_settled.clear()
        self._book_carried_turn = None
        # Entered, so whatever it confirms is being decided again. Withdrawn
        # before role_message renders, so this step never reads a confirmation
        # it is about to replace.
        _withdraw_confirmation(self.state, "verify_customer")
        self.context.set_messages(_speech_only(self.context.get_messages()))
        # The step's own line, queued rather than handed to the framework as a
        # `tts_say` pre-action, and that is not a style choice. A pre-action
        # holds the node until the ActionFinishedFrame behind it reaches the
        # worker sink, and a frame this worker queues does not move until the
        # tool call that is building this flow returns. The first node of a
        # flow is built inside that call, so the two wait on each other: on a
        # live Pipecat call on 2026-09-16 a task group was entered, said
        # nothing, asked the model nothing, and held the caller for eleven
        # seconds. Queued, nothing waits, and the line is spoken in the same
        # place it would have been.
        #
        # append_to_context=False because the seeded assistant turn below is
        # how the line enters the context. Appending here as well would put it
        # in twice.
        await self.queue_frame(
            TTSSpeakFrame(
                "Let me confirm who I'm speaking to.", append_to_context=False
            )
        )
        return NodeConfig(
            name="verify_customer",
            role_message=_render(
                '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Verify the customer\nCombine phone fragments. Ask only for missing digits or country information.\nAccept valid Spanish numbers in full international form, +34 and nine digits.\nIf the country is missing, ask; never infer it. Read every digit back, then wait for yes.\nWhen a saved number is present, read it back in the first question instead of asking\nfor a number again. Include the country code. Never drop or change digits.\nA correction needs another readback. Giving digits or asking a question isn\'t yes.\nOnly after approval, call find_or_create_customer with the confirmed number.\nThat tool finishes verification; the pending request continues without a new greeting.\nIf the caller declines or changes subject, finish with the unserved request.\nSaved number: {{customer_phone}}. Status: {{customer_verified}}.\n\n\nWhen this step is complete, call `finish_book_verify_customer` with: customer_phone, customer_status.\n\nWhen `find_or_create_customer` returns a successful result, this step ends by itself and saves it; do not call `finish_book_verify_customer` after it. `finish_book_verify_customer` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_book_verify_customer` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                self.state,
                site="task:verify_customer",
            ),
            task_messages=[
                {"role": "developer", "content": "Begin this step."},
                {"role": "assistant", "content": "Let me confirm who I'm speaking to."},
            ],
            # The seeded turn above is the line the frame spoke, and it is what
            # stops the model opening by acknowledging a sentence it would
            # otherwise not be able to see: the frame carries no context write
            # of its own, and a live call on 2026-09-16 answered its own
            # announcement with "Got it.".
            functions=[
                FlowsFunctionSchema(
                    name="find_or_create_customer",
                    description="Look up or create one salon customer from the exact confirmed phone number. Use only after the digit readback got a clear yes. Reuse the record that already owns the number, or create one for a number that is new. Never guess a number or pass one the caller has not confirmed. A caller giving a replacement number is not confirmation. Ask the readback question first; call this tool only after a later caller message agrees to it.",
                    properties={
                        "phone": {
                            "description": "The approved Spanish number in full international form, +34 followed by nine digits. Never infer country or approval.",
                            "type": "string",
                        }
                    },
                    required=["phone"],
                    handler=_flow_visit(
                        self,
                        "book",
                        self._trace_flow_tool(
                            "find_or_create_customer",
                            self._book_terminal_verify_customer_find_or_create_customer,
                        ),
                    ),
                ),
                FlowsFunctionSchema(
                    name="finish_book_verify_customer",
                    description="Record the result of this step and finish.",
                    properties={
                        "unserved_request": {
                            "description": "Leave empty unless the caller asked for something this step cannot serve. Then put that request here in one short plain sentence, in the caller's own terms, so the agent that owns this step can take it.",
                            "type": "string",
                        },
                        "customer_phone": _schema(
                            TypeAdapter(
                                Annotated[
                                    Phone | None,
                                    Field(
                                        description="The caller's phone number in E.164: a plus sign, then digits, with no spaces, brackets or dashes. One shape for every phone number in this package, the MANAGER_PHONE_NUMBER transfer destination included, so no prompt and no tool has to guess which shape it is holding.\nNo `source:` here on purpose. The prefetch block below reads the carrier's fact and this variable receives it, which leaves the per-route refusal for a variable naming a source its target cannot supply exactly as strict as it is: on a route with no caller ID the entry skips and this holds its default.\nOffered to the caller for a yes, never acted on unasked. Somebody may be ringing from a friend's phone, or may hold a second account, so until the verification step has heard them agree this value stays unconfirmed and appears in no prompt but that step's own."
                                    ),
                                ]
                            )
                        ),
                        "customer_status": _schema(
                            TypeAdapter(
                                Annotated[
                                    str | None,
                                    Field(
                                        description="Whether verification has already run on this call, and what it found. Set by the verification step as it ends, which only happens on a number the caller agreed to, so a value here means the number beside it is confirmed.\nIt exists for customer care, which has to decide whether to identify the caller before writing a complaint down and cannot read `customer_phone` to find out: an unconfirmed number renders in no prompt but the verification step's own, and a confirmed one must not be in front of an agent that might say it out loud. This carries the same fact with nothing sensitive in it.\nThe concierge does not read it. The `book` flow decides the same thing structurally with `skip_when_confirmed:`, off the confirmation itself rather than off a copy of it.\nEmpty means nobody has been verified yet on this call."
                                    ),
                                ]
                            )
                        ),
                    },
                    required=[],
                    handler=_flow_visit(
                        self,
                        "book",
                        self._trace_flow_tool(
                            "finish_book_verify_customer",
                            self._book_finish_verify_customer,
                        ),
                    ),
                ),
            ],
        )

    async def _book_terminal_verify_customer_find_or_create_customer(
        self, args, flow_manager
    ):
        """Run find_or_create_customer and end this step when it says it did the work.

        The result never reaches the model on a success: the tool has already
        made the decision the model would have been asked to confirm. Anything
        else goes back as an ordinary result and the step stays open.
        """
        if self._book_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._book_terminal is not None:
            logger.info(
                "terminal tool refused: find_or_create_customer cannot run again in this step"
            )
            return {
                "refused": "find_or_create_customer already succeeded in this step. Call finish to record it; a new action is a new request from the caller."
            }, None
        # In flight from here until settled, whichever response called it: a
        # handoff or a finish arriving while it runs waits for it rather than
        # moving the caller past an action nobody recorded.
        _visit = self._book_visit
        self._book_pending = True
        self._book_settled.clear()
        try:
            result = await _flow_tool_find_or_create_customer(args, flow_manager)
        except BaseException:
            self._book_settle()
            raise
        if (
            self._book_visit is not _visit
            or self._book_active_step != "verify_customer"
        ):
            # The flow moved while the tool ran. Nothing here may write state
            # a later step now owns, so the result goes back as it is.
            self._book_settle()
            return result, None
        if not _terminal_success(
            result,
            {
                "customer_status": (
                    "existing",
                    "created",
                )
            },
        ):
            # A failed action has nothing to save, and it still settles: a
            # handoff waiting beside it stops waiting and leaves the caller here.
            self._book_settle()
            return result, None
        self._book_terminal = ("find_or_create_customer", result)
        _messages = self.context.get_messages()
        if _caller_turns(_messages) > self._book_snapshot_turns:
            # The turn this call answered arrived after the owner's snapshot, so
            # the owner never saw it. Counted rather than matched on its text,
            # because a caller who says the same word twice has said it twice.
            self._book_carried_turn = _newest_caller_message(_messages)
        try:
            _values = _save_result("verify_customer", self.state, result)
        except _StateRefused as refused:
            # The action happened and the save did not. The step stays open so
            # the model can repair it, and its mutations stay closed so the
            # repair cannot run the action a second time.
            self._book_settle()
            logger.warning(
                "terminal find_or_create_customer: not recorded: " + refused.message
            )
            return {
                **result,
                "refused": "Not recorded: "
                + refused.message
                + ". Call finish with the values this tool returned; recover a missing one with a read tool of this step, or finish with unserved_request saying the action happened and its details could not be saved.",
            }, None
        self._book_settle()
        logger.info("step verify_customer ended on find_or_create_customer")
        # Saved once, above. The advance is the finish handler's own tail,
        # shared rather than copied, and it saves nothing itself: a second save
        # wrote a second entry onto every list an assign appends to.
        return await self._book_advance_verify_customer(_values)

    async def _book_finish_verify_customer(self, args, flow_manager):
        if self._book_active_step != "verify_customer":
            return {"status": "already handled"}, NO_RESPONSE
        if self._book_pending:
            # A tool that ends this step is still running, and its result
            # decides the step. Wait for it rather than ending the step under it
            # and leaving what it did unrecorded.
            try:
                await asyncio.wait_for(self._book_settled.wait(), timeout=30.0)
            except asyncio.TimeoutError:
                self._book_settle()
            if self._book_active_step != "verify_customer":
                return {"status": "already handled"}, NO_RESPONSE
        args = dict(args)
        if self._book_terminal is not None:
            # Repairing a save the tool already made. The tool's own values win
            # where they validate: the model cannot manufacture a reference, and
            # a repair that retyped one would record an action nobody took.
            args = _merge_retained("verify_customer", args, self._book_terminal[1])
        # Validated before anything is recorded: a value that does not fit its
        # declared type never enters the state, the previous contents stand, and
        # the message goes back to the model so it can correct itself on the next
        # turn instead of the step recording something wrong. This framework
        # validates no tool argument itself, so without this the two targets
        # would behave differently on the same package.
        try:
            _values = _save_result("verify_customer", self.state, dict(args))
        except _StateRefused as refused:
            logger.warning("finish {}: {}", "verify_customer", refused.message)
            return {
                "refused": f"Not recorded: {refused.message}. Ask again, then call finish with a value that fits."
            }, None
        return await self._book_advance_verify_customer(_values)

    async def _book_advance_verify_customer(self, _values):
        """Move the flow on with this step's saved values: the next step, the owner, or the end."""
        self._book_results["verify_customer"] = _values
        _next = self._book_next("verify_customer")
        if self._book_results["verify_customer"].get("unserved_request"):
            # The step could not serve what the caller asked. Running the next
            # one would answer a question nobody asked, so the flow stops here
            # and the owner is handed the unserved status.
            logger.info("group stopped: verify_customer ended unserved")
            _next = None
        self._book_active_step = _next
        if _next is not None:
            return _task_status(
                self._book_results["verify_customer"]
            ), await self._book_node(_next)
        flow_messages = None
        flow_tools = None
        completion_started = False
        try:
            flow_messages = copy.deepcopy(self.context.get_messages())
            flow_tools = self.context.tools
            completion_started = True
            return await self._book_complete_verify_customer()
        except BaseException as error:
            # The save already committed. Keep its terminal claim; a retry cannot save it twice.
            try:
                if flow_messages is not None:
                    self.context.set_messages(flow_messages)
                if flow_tools is not None:
                    self.context.set_tools(flow_tools)
                if completion_started:
                    await self.queue_frame(
                        LLMUpdateSettingsFrame(
                            delta=LLMSettings(
                                system_instruction=_render(
                                    '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Verify the customer\nCombine phone fragments. Ask only for missing digits or country information.\nAccept valid Spanish numbers in full international form, +34 and nine digits.\nIf the country is missing, ask; never infer it. Read every digit back, then wait for yes.\nWhen a saved number is present, read it back in the first question instead of asking\nfor a number again. Include the country code. Never drop or change digits.\nA correction needs another readback. Giving digits or asking a question isn\'t yes.\nOnly after approval, call find_or_create_customer with the confirmed number.\nThat tool finishes verification; the pending request continues without a new greeting.\nIf the caller declines or changes subject, finish with the unserved request.\nSaved number: {{customer_phone}}. Status: {{customer_verified}}.\n\n\nWhen this step is complete, call `finish_book_verify_customer` with: customer_phone, customer_status.\n\nWhen `find_or_create_customer` returns a successful result, this step ends by itself and saves it; do not call `finish_book_verify_customer` after it. `finish_book_verify_customer` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_book_verify_customer` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                                    self.state,
                                    site="task:verify_customer",
                                )
                            ),
                        )
                    )
                    await self.flush_pipeline()
            except BaseException as rollback_error:
                raise error from rollback_error
            raise

    async def _book_complete_verify_customer(self):
        # then: return — restore the owner's pre-flow context (messages and
        # tools); only a completed or unserved status crosses back.
        messages, tools = self._book_snapshot
        _settle_task_call(messages, "book", _group_status(self._book_results))
        await self.queue_frame(
            LLMUpdateSettingsFrame(
                delta=LLMSettings(
                    system_instruction=_render(
                        CONCIERGE_PROMPT, self.state, site="agent:concierge"
                    )
                ),
            )
        )
        await self.flush_pipeline()
        self.context.set_messages(
            messages
            + _carried_messages(self._book_carried_turn)
            + [
                {
                    "role": "developer",
                    "content": json.dumps(_group_status(self._book_results)),
                }
            ]
        )
        self.context.set_tools(tools)
        # Counted after the restore, so a turn a step consumed and carried back
        # is included: that turn is the one the owner is about to read, and it
        # is exactly the turn that must not be mistaken for a new request.
        self._ran_at_book = _caller_turns(self.context.get_messages())
        return {"status": "ok"}, None

    async def _book_node_manage_booking(self) -> NodeConfig:
        # This step's own ending, whatever the step before it did. Held on the
        # flow rather than the step, so the tool that ended the previous step
        # closed this one's mutations too: a verified caller was told their
        # first booking had already succeeded.
        self._book_terminal = None
        self._book_pending = False
        self._book_settled.clear()
        self._book_carried_turn = None
        self.context.set_messages(_speech_only(self.context.get_messages()))
        # The step's own line, queued rather than handed to the framework as a
        # `tts_say` pre-action, and that is not a style choice. A pre-action
        # holds the node until the ActionFinishedFrame behind it reaches the
        # worker sink, and a frame this worker queues does not move until the
        # tool call that is building this flow returns. The first node of a
        # flow is built inside that call, so the two wait on each other: on a
        # live Pipecat call on 2026-09-16 a task group was entered, said
        # nothing, asked the model nothing, and held the caller for eleven
        # seconds. Queued, nothing waits, and the line is spoken in the same
        # place it would have been.
        #
        # append_to_context=False because the seeded assistant turn below is
        # how the line enters the context. Appending here as well would put it
        # in twice.
        await self.queue_frame(
            TTSSpeakFrame("I'll check the diary.", append_to_context=False)
        )
        return NodeConfig(
            name="manage_booking",
            role_message=_render(
                '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Handle one booking change\nThe caller is identified. Use returned diary identifiers and preserve unchanged\ndetails. Save a clear selection of an offered slot immediately. An explicit move\nat the same time is approval if that slot is available. For cancellation or an\nunresolved choice, read back the action and wait for agreement before saving.\nAsk move versus additional when ambiguous; don\'t infer a second appointment.\nAfter success say the returned service and spoken date/time once. A refusal\nneeds an honest next step. A complaint goes to_complaints; abandon via finish.\nLatest appointment: {{appointment}}.\n## Availability\n\nUse `find_slots` with the caller\'s own day and time words. It resolves dates\nand returns both existing bookings and available slots. Ask for a day if\nmissing. Offer only returned slots; if none fit, ask about another day.\n\nOffer up to three times, naming the service and day once. For one time, ask\nwhether it works. If their exact requested time is free, read back the action and ask for approval.\nA selection from your offer is already agreement; save it without another\nconfirmation.\n\nFor an explicit move at the "same time", keep the existing service and time,\nread the new day\'s availability, and save the move if available. There is no\nnew choice to confirm.\n\n\nWhen this step is complete, call `finish_book_manage_booking` with: appointment.\n\nWhen `save_booking` returns a successful result, this step ends by itself and saves it; do not call `finish_book_manage_booking` after it. `finish_book_manage_booking` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_book_manage_booking` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                self.state,
                site="task:manage_booking",
            ),
            task_messages=[
                {"role": "developer", "content": "Begin this step."},
                {"role": "assistant", "content": "I'll check the diary."},
            ],
            # The seeded turn above is the line the frame spoke, and it is what
            # stops the model opening by acknowledging a sentence it would
            # otherwise not be able to see: the frame carries no context write
            # of its own, and a live call on 2026-09-16 answered its own
            # announcement with "Got it.".
            functions=[
                FlowsFunctionSchema(
                    name="find_slots",
                    description="Read current bookings and availability using the caller's own day words.",
                    properties={
                        "date": {
                            "description": "Caller day words, or empty to read existing bookings.",
                            "type": "string",
                        },
                        "prefer": {
                            "description": "Caller time preference, including afternoon or same time.",
                            "type": "string",
                        },
                        "service": {
                            "description": "Narrow the free times to one service, or `any` to see all three. Use `any` when the caller has not said which service they want.",
                            "enum": ["any", "haircut", "hair-color", "blowout"],
                            "type": "string",
                        },
                    },
                    required=["date", "service", "prefer"],
                    handler=self._trace_flow_tool(
                        "find_slots", self._bind_state(_flow_tool_find_slots)
                    ),
                ),
                FlowsFunctionSchema(
                    name="save_booking",
                    description="Save an approved action using diary IDs. A clear offered-slot selection or explicit same-time move is approval. Cancellation needs a readback and yes.",
                    properties={
                        "action": {
                            "description": "book a new time, move an existing booking, or cancel one",
                            "enum": ["book", "move", "cancel"],
                            "type": "string",
                        },
                        "additional": {
                            "description": "True only when the caller asked for a second appointment on top of one they already hold. A caller who holds a booking is changing it, so this is false for an ordinary booking and the tool refuses with has_booking.",
                            "type": "boolean",
                        },
                        "booking_id": {
                            "description": "The exact booking_id from find_slots when moving or cancelling. An empty string when booking, which has no booking yet.",
                            "type": "string",
                        },
                        "confirmed": {
                            "description": "True after a clear offered-slot selection, explicit same-time move, or approval of a readback.",
                            "type": "boolean",
                        },
                        "slot_id": {
                            "description": "The exact slot_id from find_slots when booking or moving. An empty string when cancelling, which needs no slot.",
                            "type": "string",
                        },
                    },
                    required=[
                        "action",
                        "slot_id",
                        "booking_id",
                        "confirmed",
                        "additional",
                    ],
                    handler=_flow_visit(
                        self,
                        "book",
                        self._trace_flow_tool(
                            "save_booking",
                            self._book_terminal_manage_booking_save_booking,
                        ),
                    ),
                ),
                FlowsFunctionSchema(
                    name="to_complaints",
                    description="The caller has a complaint or service problem.",
                    properties={},
                    required=[],
                    handler=_flow_visit(
                        self,
                        "book",
                        self._trace_flow_tool(
                            "to_complaints",
                            self._book_transfer_manage_booking_to_complaints,
                        ),
                    ),
                ),
                FlowsFunctionSchema(
                    name="finish_book_manage_booking",
                    description="Record the result of this step and finish.",
                    properties={
                        "unserved_request": {
                            "description": "Leave empty unless the caller asked for something this step cannot serve. Then put that request here in one short plain sentence, in the caller's own terms, so the agent that owns this step can take it.",
                            "type": "string",
                        },
                        "appointment": _schema(
                            TypeAdapter(
                                Annotated[
                                    Appointment | None,
                                    Field(
                                        description="The latest successful booking action, saved only after the tool succeeds."
                                    ),
                                ]
                            )
                        ),
                    },
                    required=[],
                    handler=_flow_visit(
                        self,
                        "book",
                        self._trace_flow_tool(
                            "finish_book_manage_booking",
                            self._book_finish_manage_booking,
                        ),
                    ),
                ),
            ],
        )

    async def _book_transfer_manage_booking_to_complaints(self, args, flow_manager):
        if self._book_active_step != "manage_booking":
            return {"status": "already handled"}, NO_RESPONSE
        if self._book_pending or any(
            name in {"save_booking"} for name in self._response_calls
        ):
            # A tool that ends this step is running, or was called in the same
            # response and has not started yet. The caller asked for two things
            # at once, and the step's own work has to be committed before the
            # caller is moved.
            try:
                await asyncio.wait_for(self._book_settled.wait(), timeout=30.0)
            except asyncio.TimeoutError:
                self._book_settle()
            if self._book_active_step != "manage_booking":
                # The flow moved on while this handoff waited.
                return {"status": "already handled"}, NO_RESPONSE
            if "manage_booking" not in self._book_results:
                logger.info("handoff held: the step's own action did not complete")
                return {"status": "not transferred: the action did not complete"}, None
        self._book_active_step = None
        flow_messages = None
        flow_tools = None
        try:
            flow_messages = copy.deepcopy(self.context.get_messages())
            flow_tools = self.context.tools
            messages, tools = self._book_snapshot
            self.context.set_messages(_speech_only(self.context.get_messages()))
            self.context.set_tools(tools)
            await self.activate_worker(
                "complaint_specialist",
                args=LLMWorkerActivationArgs(
                    metadata=self._dev.activation_metadata() if self._dev else None,
                    messages=[],
                    run_llm=True,
                ),
                deactivate_self=True,
            )
        except BaseException:
            self._book_active_step = "manage_booking"
            if flow_messages is not None:
                self.context.set_messages(flow_messages)
            if flow_tools is not None:
                self.context.set_tools(flow_tools)
            raise
        return {"transferred": True}, NO_RESPONSE

    async def _book_terminal_manage_booking_save_booking(self, args, flow_manager):
        """Run save_booking and end this step when it says it did the work.

        The result never reaches the model on a success: the tool has already
        made the decision the model would have been asked to confirm. Anything
        else goes back as an ordinary result and the step stays open.
        """
        if self._book_active_step != "manage_booking":
            return {"status": "already handled"}, NO_RESPONSE
        if self._book_terminal is not None:
            logger.info(
                "terminal tool refused: save_booking cannot run again in this step"
            )
            return {
                "refused": "save_booking already succeeded in this step. Call finish to record it; a new action is a new request from the caller."
            }, None
        # In flight from here until settled, whichever response called it: a
        # handoff or a finish arriving while it runs waits for it rather than
        # moving the caller past an action nobody recorded.
        _visit = self._book_visit
        self._book_pending = True
        self._book_settled.clear()
        try:
            result = await _flow_tool_save_booking(args, flow_manager, state=self.state)
        except BaseException:
            self._book_settle()
            raise
        if self._book_visit is not _visit or self._book_active_step != "manage_booking":
            # The flow moved while the tool ran. Nothing here may write state
            # a later step now owns, so the result goes back as it is.
            self._book_settle()
            return result, None
        if not _terminal_success(
            result,
            {
                "status": (
                    "booked",
                    "moved",
                    "cancelled",
                )
            },
        ):
            # A failed action has nothing to save, and it still settles: a
            # handoff waiting beside it stops waiting and leaves the caller here.
            self._book_settle()
            return result, None
        self._book_terminal = ("save_booking", result)
        _messages = self.context.get_messages()
        if _caller_turns(_messages) > self._book_snapshot_turns:
            # The turn this call answered arrived after the owner's snapshot, so
            # the owner never saw it. Counted rather than matched on its text,
            # because a caller who says the same word twice has said it twice.
            self._book_carried_turn = _newest_caller_message(_messages)
        try:
            _values = _save_result("manage_booking", self.state, result)
        except _StateRefused as refused:
            # The action happened and the save did not. The step stays open so
            # the model can repair it, and its mutations stay closed so the
            # repair cannot run the action a second time.
            self._book_settle()
            logger.warning("terminal save_booking: not recorded: " + refused.message)
            return {
                **result,
                "refused": "Not recorded: "
                + refused.message
                + ". Call finish with the values this tool returned; recover a missing one with a read tool of this step, or finish with unserved_request saying the action happened and its details could not be saved.",
            }, None
        self._book_settle()
        logger.info("step manage_booking ended on save_booking")
        if any(name in {"to_complaints"} for name in self._response_calls):
            # A handoff was called in the same response. It owns the ending: the
            # save is committed, and advancing here would race its transition.
            # Recorded first, because the handoff reads this to know the step's
            # own work actually landed.
            self._book_results["manage_booking"] = _values
            return _task_status(_values), NO_RESPONSE
        # Saved once, above. The advance is the finish handler's own tail,
        # shared rather than copied, and it saves nothing itself: a second save
        # wrote a second entry onto every list an assign appends to.
        return await self._book_advance_manage_booking(_values)

    async def _book_finish_manage_booking(self, args, flow_manager):
        if self._book_active_step != "manage_booking":
            return {"status": "already handled"}, NO_RESPONSE
        if self._book_pending:
            # A tool that ends this step is still running, and its result
            # decides the step. Wait for it rather than ending the step under it
            # and leaving what it did unrecorded.
            try:
                await asyncio.wait_for(self._book_settled.wait(), timeout=30.0)
            except asyncio.TimeoutError:
                self._book_settle()
            if self._book_active_step != "manage_booking":
                return {"status": "already handled"}, NO_RESPONSE
        args = dict(args)
        if self._book_terminal is not None:
            # Repairing a save the tool already made. The tool's own values win
            # where they validate: the model cannot manufacture a reference, and
            # a repair that retyped one would record an action nobody took.
            args = _merge_retained("manage_booking", args, self._book_terminal[1])
        # Validated before anything is recorded: a value that does not fit its
        # declared type never enters the state, the previous contents stand, and
        # the message goes back to the model so it can correct itself on the next
        # turn instead of the step recording something wrong. This framework
        # validates no tool argument itself, so without this the two targets
        # would behave differently on the same package.
        try:
            _values = _save_result("manage_booking", self.state, dict(args))
        except _StateRefused as refused:
            logger.warning("finish {}: {}", "manage_booking", refused.message)
            return {
                "refused": f"Not recorded: {refused.message}. Ask again, then call finish with a value that fits."
            }, None
        return await self._book_advance_manage_booking(_values)

    async def _book_advance_manage_booking(self, _values):
        """Move the flow on with this step's saved values: the next step, the owner, or the end."""
        self._book_results["manage_booking"] = _values
        _next = self._book_next("manage_booking")
        if self._book_results["manage_booking"].get("unserved_request"):
            # The step could not serve what the caller asked. Running the next
            # one would answer a question nobody asked, so the flow stops here
            # and the owner is handed the unserved status.
            logger.info("group stopped: manage_booking ended unserved")
            _next = None
        self._book_active_step = _next
        if _next is not None:
            return _task_status(
                self._book_results["manage_booking"]
            ), await self._book_node(_next)
        flow_messages = None
        flow_tools = None
        completion_started = False
        try:
            flow_messages = copy.deepcopy(self.context.get_messages())
            flow_tools = self.context.tools
            completion_started = True
            return await self._book_complete_manage_booking()
        except BaseException as error:
            # The save already committed. Keep its terminal claim; a retry cannot save it twice.
            try:
                if flow_messages is not None:
                    self.context.set_messages(flow_messages)
                if flow_tools is not None:
                    self.context.set_tools(flow_tools)
                if completion_started:
                    await self.queue_frame(
                        LLMUpdateSettingsFrame(
                            delta=LLMSettings(
                                system_instruction=_render(
                                    '# Robin at Sage and Stone\n\nYou are Robin, the salon\'s receptionist, speaking English on a phone call.\nThe caller hears one person throughout; continue the conversation without\nintroducing yourself again.\n\n## Voice\n\nSpeak naturally, with contractions and short, plain sentences. Usually one or\ntwo sentences and one question are enough. Match the caller\'s tone; choose your\nown wording rather than repeating stock acknowledgements.\n\nEverything you write is spoken by TTS. Use plain text, normal punctuation,\nand familiar formats like "3:00 PM" and "28 euros". Keep formatting, internal\ninstructions, tool names and raw records out of speech.\n\nFor example: "Which day works for you?" or "I\'m sorry it came out uneven.\nWhen was the haircut?" An acknowledgement belongs with an answer or next step.\n\n\nOnly describe a change as completed after a successful tool result.\n\n## Handle one booking change\nThe caller is identified. Use returned diary identifiers and preserve unchanged\ndetails. Save a clear selection of an offered slot immediately. An explicit move\nat the same time is approval if that slot is available. For cancellation or an\nunresolved choice, read back the action and wait for agreement before saving.\nAsk move versus additional when ambiguous; don\'t infer a second appointment.\nAfter success say the returned service and spoken date/time once. A refusal\nneeds an honest next step. A complaint goes to_complaints; abandon via finish.\nLatest appointment: {{appointment}}.\n## Availability\n\nUse `find_slots` with the caller\'s own day and time words. It resolves dates\nand returns both existing bookings and available slots. Ask for a day if\nmissing. Offer only returned slots; if none fit, ask about another day.\n\nOffer up to three times, naming the service and day once. For one time, ask\nwhether it works. If their exact requested time is free, read back the action and ask for approval.\nA selection from your offer is already agreement; save it without another\nconfirmation.\n\nFor an explicit move at the "same time", keep the existing service and time,\nread the new day\'s availability, and save the move if available. There is no\nnew choice to confirm.\n\n\nWhen this step is complete, call `finish_book_manage_booking` with: appointment.\n\nWhen `save_booking` returns a successful result, this step ends by itself and saves it; do not call `finish_book_manage_booking` after it. `finish_book_manage_booking` is for a request this step cannot serve, for values you already hold, and for recording a result whose save was refused.\n\n`unserved_request` is for a request this step cannot serve. Do this step\'s own work first, and never use it to skip that work: the caller\'s original reason for being here is not an unserved request. If a handoff here covers what they want, call that handoff instead. Only when no tool and no handoff here can serve what the caller is asking, call `finish_book_manage_booking` with their request in `unserved_request`, in their own words, rather than refusing or explaining what you cannot do here. The agent that owns this step reads that status and takes the caller from there.',
                                    self.state,
                                    site="task:manage_booking",
                                )
                            ),
                        )
                    )
                    await self.flush_pipeline()
            except BaseException as rollback_error:
                raise error from rollback_error
            raise

    async def _book_complete_manage_booking(self):
        # then: return — restore the owner's pre-flow context (messages and
        # tools); only a completed or unserved status crosses back.
        messages, tools = self._book_snapshot
        _settle_task_call(messages, "book", _group_status(self._book_results))
        await self.queue_frame(
            LLMUpdateSettingsFrame(
                delta=LLMSettings(
                    system_instruction=_render(
                        CONCIERGE_PROMPT, self.state, site="agent:concierge"
                    )
                ),
            )
        )
        await self.flush_pipeline()
        self.context.set_messages(
            messages
            + _carried_messages(self._book_carried_turn)
            + [
                {
                    "role": "developer",
                    "content": json.dumps(_group_status(self._book_results)),
                }
            ]
        )
        self.context.set_tools(tools)
        # Counted after the restore, so a turn a step consumed and carried back
        # is included: that turn is the one the owner is about to read, and it
        # is exactly the turn that must not be mistaken for a new request.
        self._ran_at_book = _caller_turns(self.context.get_messages())
        return {"status": "ok"}, None


def _caller_turns(messages):
    """How many turns the caller has taken in this message list.

    Read by every delegate, not just the ones that carry a turn: it is the one
    signal that separates "they asked again" from "the model re-read its own
    finished work", which is what the re-entry guard compares.
    """
    return sum(
        1
        for message in messages
        if isinstance(message, dict) and message.get("role") == "user"
    )


def _newest_caller_message(messages):
    """The caller turn a terminal tool call answered.

    Carried back to the owner when the step ends on its own tool, because the
    owner never saw it: the step consumed the turn and the owner's snapshot was
    taken before it arrived.
    """
    for message in reversed(messages):
        if isinstance(message, dict) and message.get("role") == "user":
            return dict(message)
    return None


def _carried_messages(carried):
    """That turn as a list to splice in, empty when there is nothing to carry.

    Whether there is one was decided where it was captured, by counting the
    caller's turns against the owner's snapshot rather than matching text, so a
    caller who repeated a word is not read as having said it once.
    """
    if not carried:
        return []
    logger.info("carried the caller's turn back to the owner")
    return [carried]


def _settle_task_call(messages, name, status):
    """Replace this invocation's running reply before restoring the owner."""
    for message in reversed(messages):
        if not isinstance(message, dict):
            continue
        for call in message.get("tool_calls", []):
            if call.get("function", {}).get("name") == name:
                for reply in messages:
                    if (
                        isinstance(reply, dict)
                        and reply.get("role") == "tool"
                        and reply.get("tool_call_id") == call["id"]
                    ):
                        reply["content"] = json.dumps(status)
                return


def _flow_visit(worker, delegate, handler):
    visit = getattr(worker, "_" + delegate + "_visit", None)

    async def invoke(args, flow_manager):
        if getattr(worker, "_" + delegate + "_visit", None) is not visit:
            return {"status": "already handled"}, NO_RESPONSE
        return await handler(args, flow_manager)

    return invoke


# --- task tools (flows handlers) ----------------------------------------------
# Tools available inside task steps; stable module-level handlers so a
# re-registered function name always resolves to the same callable.


async def _flow_tool_find_or_create_customer(args, flow_manager):
    """Look up or create one salon customer from the exact confirmed phone number. Use only after the digit readback got a clear yes. Reuse the record that already owns the number, or create one for a number that is new. Never guess a number or pass one the caller has not confirmed. A caller giving a replacement number is not confirmation. Ask the readback question first; call this tool only after a later caller message agrees to it."""
    result = tools.find_or_create_customer.find_or_create_customer(**dict(args))
    if inspect.isawaitable(result):
        result = await result
    return result


async def _flow_tool_find_slots(args, flow_manager, state=None):
    """Read current bookings and availability using the caller's own day words."""
    refusal = _refusal(
        "find_slots", state, [("customer_phone", "run verify_customer first.")]
    )
    if refusal:
        return {"refused": refusal}
    result = tools.find_slots.find_slots(
        **dict(args), customer_phone=state.customer_phone
    )
    if inspect.isawaitable(result):
        result = await result
    return result


async def _flow_tool_save_booking(args, flow_manager, state=None):
    """Save an approved action using diary IDs. A clear offered-slot selection or explicit same-time move is approval. Cancellation needs a readback and yes."""
    refusal = _refusal(
        "save_booking", state, [("customer_phone", "run verify_customer first.")]
    )
    if refusal:
        return {"refused": refusal}
    result = tools.save_booking.save_booking(
        **dict(args), customer_phone=state.customer_phone
    )
    if inspect.isawaitable(result):
        result = await result
    return result


# --- transport & run --------------------------------------------------------
transport_params: dict = {
    "webrtc": lambda: TransportParams(audio_in_enabled=True, audio_out_enabled=True),
    # The runner assigns an inbound call's dial-in settings and Daily credentials
    # onto whatever this returns, so on the Daily route it has to be the params
    # class that declares them. The generic one rejects the assignment.
    "daily": lambda: TransportParams(audio_in_enabled=True, audio_out_enabled=True),
    # Your carrier's stream, terminated by Pipecat Cloud. The runner attaches the
    # carrier's frame serializer itself, reading the stream and call ids out of the
    # handshake, so this declares the audio directions and nothing else.
    "twilio": lambda: FastAPIWebsocketParams(
        audio_in_enabled=True, audio_out_enabled=True
    ),
}


def build_stt():
    return SlngSTTService(
        api_key=os.environ["SLNG_API_KEY"],
        base_url="eu-north.api.slng.ai",
        model="soniox/speech-ai:rt-v5",
        language=Language("en"),
    )


async def _run_bot(transport: BaseTransport, runner_args: RunnerArguments, dev) -> None:
    require_env()
    call_context = {}
    # Decided once, right after the transport exists: is this a phone call at all?
    # Everything a call needs is checked here, before the caller hears anything.
    # None means browser or console, which behave exactly as they do on a package
    # with no telephony.
    phone_call = _phone_session(runner_args)
    call_context["_phone_call"] = phone_call
    # The call's own facts, under the flat names a `source:` reads. The call id
    # and stream id are parsed out of the carrier's handshake; the rest are the
    # <Parameter> set the TwiML markup dictated, which is why the runbook says
    # what each one is for and what happens when an existing Bin lacks it.
    if phone_call is not None:
        _markup = phone_call.get("body") or {}
        call_context["call_id"] = phone_call.get("call_id") or ""
        call_context["stream_id"] = phone_call.get("stream_id") or ""
        call_context["direction"] = _markup.get("direction") or "inbound"
        call_context["from_number"] = _markup.get("from_number") or ""
        call_context["to_number"] = _markup.get("to_number") or ""

    trace_provider = setup_langfuse_tracing()
    trace_attributes = {"langfuse.trace.name": TRACE_NAME}
    if runner_args.session_id is not None:
        trace_attributes["langfuse.session.id"] = runner_args.session_id
    # Pipecat puts these on the conversation span only. Langfuse v4 filters and
    # sums over observations, so they have to reach every span under it too, and
    # this is also where the container forgets the call it ran before.
    start_call(trace_attributes)

    runner = WorkerRunner(handle_sigint=runner_args.handle_sigint)

    # turn: local — end-of-turn detection runs on-device (Silero VAD). No API
    # key, no network hop; the turn binding in targets.yaml is advisory.
    context = LLMContext()
    state = build_state(call_context)
    # Facts knowable before the greeting, resolved once, here: after the state
    # exists so there is somewhere to put them, and before the agents are built
    # so every prompt they render already sees them.
    await _prefetch(state, call_context)
    agents = [
        ComplaintSpecialistAgent(
            state=state, context=context, call_context=call_context, dev_metrics=dev
        ),
        ConciergeAgent(
            state=state, context=context, call_context=call_context, dev_metrics=dev
        ),
    ]
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(
            # The FLOOR: how long silence has to last before speech counts as
            # stopped. Authored as endpointing_delay.
            #
            # Widening this window makes some turns SLOWER, not more patient.
            # pipecat-slng asks the bridge to finalise when VAD reports the caller
            # stopped, and a final that already arrived finds no request
            # outstanding, so the frame goes out unfinalized and Pipecat waits out
            # a flat 1.0s safety net. Observed transcripts arrive from 0.27s.
            vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=0.2)),
            # The CEILING, on the end-of-turn analyzer. pace: balanced.
            #
            # Note the two fields both spelled stop_secs. The one above is the
            # VAD's silence window; this one is how long the turn may run before
            # closing regardless. They are different fields and different numbers.
            #
            # The analyzer is Pipecat's own default stop strategy. It is
            # constructed explicitly here only so the ceiling is reachable: left
            # implicit it runs at SmartTurnParams' own 3s.
            user_turn_strategies=UserTurnStrategies(
                stop=[
                    TurnAnalyzerUserTurnStopStrategy(
                        turn_analyzer=LocalSmartTurnAnalyzerV3(
                            params=SmartTurnParams(stop_secs=1.5)
                        )
                    )
                ],
            ),
            # The stretches of the call the caller cannot talk over, lowered from
            # conversation.interruption. On a phone route the greeting is
            # protected by default: a phone leg has no echo cancellation, so
            # without this the agent hears its own opening line and cuts itself
            # off. Barge-in stays on everywhere else.
            user_mute_strategies=[],
            user_idle_timeout=15,
        ),
    )
    bridge = BusBridgeProcessor(
        bus=runner.bus, worker_name=MAIN_NAME, name=f"{MAIN_NAME}::BusBridge"
    )
    dev.observe_aggregators(user_aggregator, assistant_aggregator)
    pipeline = Pipeline(
        [
            transport.input(),
            dev.observe_stt(build_stt()),
            user_aggregator,
            bridge,
            transport.output(),
            assistant_aggregator,
        ]
    )
    main = PipelineWorker(
        pipeline,
        name=MAIN_NAME,
        # The worker builds its own latency observer only when tracing is enabled,
        # and does not re-expose its events, so this one is always ours.
        observers=dev.observers(),
        conversation_id=runner_args.session_id,
        enable_tracing=True,
        additional_span_attributes=trace_attributes,
        params=PipelineParams(
            enable_metrics=True,
            enable_usage_metrics=True,
            **_pipeline_audio_rates(phone_call),
        ),
    )

    enable_agent_tracing(main, agents)

    @user_aggregator.event_handler("on_user_turn_idle")
    async def on_user_turn_idle(aggregator):
        await aggregator.push_frame(
            LLMMessagesAppendFrame(
                [
                    {
                        "role": "developer",
                        "content": "The caller has gone quiet. Politely check if they are still there.",
                    }
                ],
                run_llm=True,
            )
        )

    # inactivity.end_after: the nudge above is the first half, and this is the
    # second. Without it an idle call is nudged forever and never hung up, which
    # on a phone line is a billed open call. The clock starts at the first idle
    # turn and is cancelled by the caller speaking again.
    _idle_end: asyncio.Task | None = None

    @user_aggregator.event_handler("on_user_turn_idle")
    async def on_user_turn_idle_end(aggregator):
        nonlocal _idle_end
        if _idle_end is None or _idle_end.done():
            _idle_end = asyncio.create_task(_end_after(main, 45 - 15))

    @user_aggregator.event_handler("on_user_turn_started")
    async def on_user_turn_started(aggregator, strategy):
        nonlocal _idle_end
        if _idle_end is not None and not _idle_end.done():
            _idle_end.cancel()
            _idle_end = None

    runner_ready = asyncio.Event()
    pipeline_started = asyncio.Event()
    worker_start_error = None
    entry_started = False

    async def activate_entry():
        nonlocal entry_started
        if entry_started or worker_start_error is not None:
            return
        entry_started = True
        await main.activate_worker(
            "concierge",
            args=LLMWorkerActivationArgs(run_llm=False),
        )
        await next(agent for agent in agents if agent.name == "concierge").queue_frame(
            TTSSpeakFrame(
                "Hi, you've reached Sage and Stone. Robin speaking, what can I do for you?"
            )
        )

        asyncio.create_task(_end_after(main, 900))

    @runner.event_handler("on_ready")
    async def on_runner_ready(runner):
        runner_ready.set()

    @main.event_handler("on_pipeline_started")
    async def on_pipeline_started(worker, frame):
        nonlocal worker_start_error
        await runner_ready.wait()
        try:
            await runner.add_workers(*agents)
        except Exception as error:
            worker_start_error = error
            # Logged here, where it is still known. Cancelling the runner makes
            # run() raise CancelledError, and that reaches the caller before the
            # re-raise below ever runs, so this error is destroyed on its way
            # out: measured 2026-08-21, a session died half a second in and
            # reported nothing but a failed trace flush.
            logger.exception("the agent workers failed to start")
            pipeline_started.set()
            await runner.cancel(reason="agent worker startup failed")
            return
        pipeline_started.set()

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        # Telephony transports (Daily SIP, the platform's carrier stream) have
        # no RTVI client-ready handshake: the carrier opens the media stream and
        # the bot initiates once that connection is open and main's StartFrame
        # has traversed (Pipecat Twilio dial-in flow; SPEC V2).
        #
        # This is also all an outbound call needs. Your carrier opens the stream
        # when the person answers, so the greeting below meets a human rather
        # than ringback, and there is no ringing state to handle.
        await pipeline_started.wait()
        await activate_entry()

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        await runner.cancel()

    try:
        await runner.add_workers(main)
        await runner.run()
        if worker_start_error is not None:
            raise worker_start_error
    finally:
        primary_error = sys.exception()
        if primary_error is not None:
            try:
                await asyncio.to_thread(flush_tracing, trace_provider)
            except BaseException as cleanup_error:
                logger.error(
                    "Tracing flush failed while preserving the primary error ({})",
                    type(cleanup_error).__name__,
                )
        else:
            await asyncio.to_thread(flush_tracing, trace_provider)


async def run_bot(transport: BaseTransport, runner_args: RunnerArguments) -> None:
    dev = install_dev_metrics(runner_args)
    try:
        await _run_bot(transport, runner_args, dev)
    except Exception as error:
        # The dev page is where the author is looking when a call dies, so it
        # names what stopped it. The type only: an exception's message quotes
        # whatever it was working on, and that belongs in the log rather than
        # on a page that carries no prompts, arguments or results.
        dev.finish(error=True, reason=f"The agent stopped on {type(error).__name__}.")
        raise
    finally:
        dev.finish()


async def bot(runner_args: RunnerArguments) -> None:
    _configure_logging()

    transport = await create_transport(runner_args, transport_params)
    await run_bot(transport, runner_args)


if __name__ == "__main__":
    from pipecat.runner.run import main

    main()
