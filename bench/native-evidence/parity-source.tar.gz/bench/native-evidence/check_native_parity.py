"""Offline native Worker/Flows regression; pass the installed native site-packages path.

Append --drop-handlers for the negative control reproducing custom-only tool registration.
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / 'bench/raw/native-reference/examples/salon-concierge/build/pipecat'
sys.path.insert(0, str(ROOT))
if len(sys.argv) > 1:
    sys.path.append(sys.argv[1])
for name in json.loads((BUILD / 'compile-report.json').read_text())['required_env']:
    os.environ[name] = 'offline-parity-check'


async def check():
    from google.genai.types import Candidate, Content, FunctionCall, GenerateContentResponse, Part
    from loguru import logger
    from pipecat.services.google.llm import GoogleLLMService

    from bench.native_compare import fixture, native, score

    logger.remove()
    logger.add(sys.stderr, level='WARNING')
    responses = [
        ('read_diary', {'when': 'Saturday', 'service': 'haircut', 'at': '15:00'}),
        ('hand_over', {'to': 'booking', 'because': 'Move the saved haircut.'}),
        ('save_booking', {'action': 'move', 'slot_id': '2026-09-26T1500|haircut', 'booking_id': 'BK0001'}),
    ]
    seen = []

    async def scripted(service, context):
        index = len(seen)
        assert index < len(responses), 'Unexpected extra request or failed tool execution'
        name, args = responses[index]
        tools = service.get_llm_adapter().to_provider_tools_format(context.tools)
        schemas = {t['name']: t for group in tools for t in group['function_declarations']}
        assert name in schemas and name in service._functions, (name, service._functions)
        assert schemas[name]['parameters_json_schema']['additionalProperties'] is False
        if index == 2:
            assert schemas['hand_over']['parameters_json_schema']['properties']['to']['enum'] == [
                'concierge',
                'complaints',
            ]
        seen.append(name)
        if index == 0 and '--drop-handlers' in sys.argv:
            from pipecat.adapters.schemas.tools_schema import AdapterType, ToolsSchema

            context.set_tools(ToolsSchema([], {AdapterType.GEMINI: tools}))

        async def chunks():
            yield GenerateContentResponse(
                candidates=[
                    Candidate(
                        content=Content(
                            role='model',
                            parts=[
                                Part(function_call=FunctionCall(name=name, args=args, id=f'probe-{index}'))
                            ],
                        )
                    )
                ]
            )

        return chunks()

    rows = []
    with patch.object(GoogleLLMService, '_stream_content', scripted):
        await native('move', fixture('move'), BUILD, rows, tool_parity=True)
    assert seen == [name for name, _ in responses], seen
    assert not score('move', rows), rows
    assert rows[-1]['state']['writes'] == 1
    print(
        'Native Worker/Flows: full schemas, registered handlers across requests, handoff and one validated move pass offline.'
    )


if __name__ == '__main__':
    asyncio.run(check())
