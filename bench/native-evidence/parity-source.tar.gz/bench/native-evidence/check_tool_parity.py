"""Offline contract equivalence and validation checks; run from the repository root."""

import asyncio
import sys
from contextlib import suppress
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pydantic_ai.models
from pydantic import ValidationError
from pydantic_ai import ModelRetry
from pydantic_ai.messages import ModelResponse, ToolCallPart
from pydantic_ai.models import ModelRequestParameters
from pydantic_ai.models.function import FunctionModel

from bench.native_parity import context_model, invoke, offered, provider_tools, tool_config
from salon import diary
from salon.agents import AGENTS, Ask
from salon.state import Asked, SalonCall, SalonState

pydantic_ai.models.ALLOW_MODEL_REQUESTS = False
PHONE = '+34600111222'


class CapturedError(Exception):
    """Stop at the real SDK request boundary, before any tool executes."""


def fresh(role: str, verified: bool = True) -> SalonCall:
    return SalonCall(
        state=SalonState.model_validate(
            {
                'agent': role,
                'customer_phone': PHONE,
                'customer_verified': 'existing' if verified else '',
                'verified_phone': PHONE if verified else '',
            }
        )
    )


async def execute(call: SalonCall, name: str, **args):
    part = ToolCallPart(name, args, 'probe')
    return await invoke(call, call.state.agent, name, args, [part], part.tool_call_id)


async def checks() -> None:
    captures = 0
    for role in AGENTS:
        for verified in (False, True):
            for approved in (False, True):
                call = fresh(role, verified)
                if approved:
                    call.ask(
                        Asked(
                            about='complaint',
                            summary='Uneven haircut',
                            requested_resolution='A refund',
                            owner=PHONE,
                        )
                    )
                call.turn_started('Yes, that is right.')
                actual = {}
                wire = {}

                def observe(messages, info, actual=actual, wire=wire, role=role):
                    actual.update(
                        {
                            tool.name: {
                                'name': tool.name,
                                'description': tool.description,
                                'parameters_json_schema': tool.parameters_json_schema,
                            }
                            for tool in [*info.function_tools, *info.output_tools]
                        }
                    )
                    model = context_model(role)
                    _, parameters = model.prepare_request(
                        None,
                        ModelRequestParameters(
                            output_mode='tool',
                            function_tools=info.function_tools,
                            output_tools=info.output_tools,
                            allow_text_output=info.allow_text_output,
                        ),
                    )
                    tools, config, _ = model._get_tool_config(parameters, {})
                    wire.update(
                        {
                            'tools': [
                                tool for group in tools or [] for tool in group['function_declarations']
                            ],
                            'config': config,
                        }
                    )
                    raise CapturedError

                node = AGENTS[role]
                with node.agent.override(model=FunctionModel(function=observe)), suppress(CapturedError):
                    await node.agent.run('Inspect.', deps=call, output_type=node.outputs(call.state))
                assert actual == offered(call, role), (role, verified, approved, actual, offered(call, role))
                assert wire['tools'] == provider_tools(call, role), (
                    role,
                    wire['tools'],
                    provider_tools(call, role),
                )
                assert wire['config'] == tool_config(role), (role, wire['config'], tool_config(role))
                captures += 1

    call = fresh('booking')
    call.turn_started('A haircut on Friday afternoon.')
    requests = 0

    def repeated_lookup(messages, info):
        nonlocal requests
        requests += 1
        assert [t.name for t in info.function_tools] == [
            name for name in offered(call, 'booking', requests) if name == 'read_diary'
        ]
        if requests == 3:
            assert not info.function_tools and info.output_tools
            raise CapturedError
        return ModelResponse(parts=[ToolCallPart('read_diary', {'when': 'Friday', 'service': 'haircut'})])

    with (
        AGENTS['booking'].agent.override(model=FunctionModel(function=repeated_lookup)),
        suppress(CapturedError),
    ):
        await AGENTS['booking'].agent.run(call.heard, deps=call)
    assert requests == 3
    with patch.object(diary, 'find_slots', wraps=diary.find_slots) as handler:
        for args in (
            {'when': 'Friday'},
            {'when': 7, 'service': 'haircut'},
            {'when': 'Friday', 'service': 'invalid'},
            {'when': 'Friday', 'service': 'haircut', 'customer_phone': PHONE},
        ):
            try:
                await execute(call, 'read_diary', **args)
            except ValidationError:
                pass
            else:
                raise AssertionError(f'Invalid input reached the handler: {args}')
        assert handler.call_count == 0
    previous = call.state.model_dump()
    with patch.object(diary, 'find_slots', return_value={'status': 'ok', 'date': '2026-02-30'}):
        try:
            await execute(call, 'read_diary', when='Friday', service='haircut')
        except ValidationError:
            pass
        else:
            raise AssertionError('Malformed service result was accepted')
    assert call.state.model_dump() == previous

    call = fresh('verify', False)
    call.turn_started(f'My number is {PHONE}.')
    with patch.object(diary, 'find_or_create_customer', wraps=diary.find_or_create_customer) as handler:
        try:
            await execute(call, 'ask_number', phone='+348340464')
        except ValidationError:
            pass
        else:
            raise AssertionError('Short number passed typed validation')
        try:
            await execute(call, 'confirm_customer', phone=PHONE)
        except ModelRetry:
            pass
        else:
            raise AssertionError('Lookup skipped readback approval')
        assert handler.call_count == 0
        question = await execute(call, 'ask_number', phone=PHONE)
        assert isinstance(question, Ask)
        question.put(call)
        call.turn_started('Go for it.')
        await execute(call, 'confirm_customer', phone=PHONE)
        assert handler.call_count == 1 and call.state.customer_verified
    print(
        f'{captures} prepared tool sets and Gemini wire schemas/configurations match exactly; third-request tool cutoff matches; invalid input/injected overrides invoke zero handlers; malformed results leave state unchanged; readback approval remains required.'
    )


if __name__ == '__main__':
    asyncio.run(checks())
