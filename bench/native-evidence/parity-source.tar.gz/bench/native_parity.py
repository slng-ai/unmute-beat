"""Native Pipecat Flows over the POC's unchanged, validated tool contract.

The benchmark shares tool definitions, business handlers and Pydantic state.
Pipecat owns model execution, tool dispatch, context and node transitions here;
no Pydantic AI Agent.run or voice.core turn loop is used by this arm.
"""

from copy import deepcopy
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from pydantic import BaseModel, ValidationError
from pydantic_ai import ModelRetry, RunContext, Tool, ToolOutput
from pydantic_ai.messages import ModelResponse, ToolCallPart
from pydantic_ai.models import infer_model
from pydantic_ai.profiles.google import GoogleJsonSchemaTransformer
from pydantic_ai.usage import RunUsage

from salon.agents import ACTIONS, AGENTS, FILLER, SPEAK_BY, Ask, prompt
from salon.state import Handoff, SalonCall, SalonState
from voice.harness import TurnBudget, pick


@dataclass(frozen=True)
class Contract:
    tool: Tool
    output: bool


@lru_cache
def declared(role: str) -> dict[str, Contract]:
    """Reuse existing handlers and their generated validators; introduce no tool."""
    node = AGENTS[role]
    tools = {name: Contract(tool, False) for name, tool in node.agent._function_toolset.tools.items()}
    for output in node.outputs(SalonState()):
        if isinstance(output, ToolOutput):
            tool = Tool(output.output, name=output.name, description=output.description)
            tools[tool.name] = Contract(tool, True)
    return tools


@lru_cache
def context_model(role: str):
    """Supply the SDK context type; native Pipecat alone executes the model."""
    model = AGENTS[role].agent.model
    assert model is not None
    return infer_model(model)


def offered(call: SalonCall, role: str, run_step: int = 1) -> dict[str, dict]:
    """Apply the same declared edge guards at each native model request."""
    node = AGENTS[role]
    borrowed = {fn.__name__: edge for edge in node.exits for fn in edge.via}
    legal = list(dict.fromkeys(edge.to for edge in node.exits if edge.guard(call.state)))
    result = {}
    for name, contract in declared(role).items():
        if node.model_speech and run_step >= SPEAK_BY and not contract.output:
            continue
        if name in borrowed and not borrowed[name].guard(call.state):
            continue
        if name == 'record_complaint' and (not call.state.customer_verified or not call.complaint_approved):
            continue
        schema = deepcopy(contract.tool.function_schema.json_schema)
        if name == 'hand_over':
            if not legal:
                continue
            schema['properties']['to'].pop('const', None)
            schema['properties']['to']['enum'] = legal
        result[name] = {
            'name': name,
            'description': contract.tool.description,
            'parameters_json_schema': schema,
        }
    return result


def provider_tools(call: SalonCall, role: str, run_step: int = 1) -> list[dict]:
    """Use the same Gemini JSON Schema adaptation, without executing its SDK model."""
    return [
        definition
        | {'parameters_json_schema': GoogleJsonSchemaTransformer(definition['parameters_json_schema']).walk()}
        for definition in offered(call, role, run_step).values()
    ]


def tool_config(role: str) -> dict:
    mode = 'ANY'
    if AGENTS[role].model_speech:
        mode = (
            'VALIDATED'
            if context_model(role).profile.get('google_supports_strict_tool_definition')
            else 'AUTO'
        )
    return {'function_calling_config': {'mode': mode}}


async def invoke(
    call: SalonCall,
    role: str,
    name: str,
    args: dict,
    calls: list[ToolCallPart],
    call_id: str,
    run_step: int = 1,
) -> Any:
    """Validate before invocation, inject authoritative context, retain service checks."""
    if name not in offered(call, role, run_step):
        raise ModelRetry(f'{name} is not available in this state. Nothing was done.')
    contract = declared(role)[name]
    arguments = contract.tool.function_schema.validator.validate_python(args)
    call._claim = next((part.tool_call_id for part in calls if part.tool_name in ACTIONS), None)
    ctx = RunContext(
        deps=call,
        model=context_model(role),
        usage=RunUsage(),
        tool_name=name,
        tool_call_id=call_id,
        messages=[ModelResponse(parts=calls)],
    )
    return await contract.tool.function_schema.call(arguments, ctx)


def worker_for(bot: Any, call: SalonCall, context: Any, sink: Any, done: Any) -> Any:
    """Use the reference's provider configuration with a native four-node flow."""
    from pipecat.adapters.schemas.tools_schema import ToolsSchema
    from pipecat.flows import NO_RESPONSE, FlowManager, FlowsFunctionSchema, NodeConfig
    from pipecat.frames.frames import TTSSpeakFrame
    from pipecat.pipeline.pipeline import Pipeline
    from pipecat.processors.aggregators.llm_response_universal import LLMContextAggregatorPair
    from pipecat.workers.llm import LLMWorker

    class MatchedWorker(LLMWorker):
        def __init__(self) -> None:
            llm = bot.build_concierge_llm()
            llm._run_in_parallel = False
            super().__init__('concierge', llm=llm, pipeline=Pipeline([llm, sink]), bridged=())
            self.context = context
            self.call = call
            self.role: str = call.state.agent
            self.calls: list[ToolCallPart] = []
            self.handled: set[str] = set()
            self.borrowed = False
            self.requests = 0
            self.run_step = 0
            self.budget = TurnBudget()
            self.invocations = 0
            self.hops = 0
            self.retries: dict[str, int] = {}
            self.terminal = False
            self.status = 'answered'
            self.detail = ''
            self.prepared: list[dict] = []
            self.flow = FlowManager(
                llm=llm, context_aggregator=LLMContextAggregatorPair(context), worker=self
            )
            call._say = self.say
            call._end = self.finish
            original = llm._stream_content
            original_process = llm._process_context

            def wire_tools(tools_schema):
                return [
                    {'function_declarations': [tool]}
                    for tool in provider_tools(call, self.role, self.run_step)
                ]

            llm.get_llm_adapter().to_provider_tools_format = wire_tools

            async def bounded_process(ctx):
                if self.requests >= self.budget.model_requests:
                    await self.exhausted('eight requests')
                    self.response_finished()
                    return
                await original_process(ctx)

            llm._process_context = bounded_process

            async def prepare(ctx):
                self.requests += 1
                self.run_step += 1
                tools = provider_tools(call, self.role, self.run_step)
                # Keep Flows' handler-carrying schemas registered across requests.
                # Only the wire adapter changes: Gemini gets the full POC JSON Schema.
                ctx.set_tools(
                    ToolsSchema(
                        standard_tools=[
                            tool
                            for tool in ctx.tools.standard_tools
                            if tool.name in offered(call, self.role, self.run_step)
                        ],
                    )
                )
                llm._settings.system_instruction = prompt(self.role).render(call) + '\n' + call._return_status
                llm._tool_config = tool_config(self.role)
                self.prepared.append(
                    {'role': self.role, 'tools': deepcopy(tools), 'tool_config': deepcopy(llm._tool_config)}
                )
                self.terminal = False
                return await original(ctx)

            llm._stream_content = prepare

            @llm.event_handler('on_function_calls_started')
            async def preflight(service, function_calls):
                self.handled = set()
                self.calls = [
                    ToolCallPart(part.function_name, dict(part.arguments), part.tool_call_id)
                    for part in function_calls
                ]

        async def say(self, text: str) -> None:
            await self.queue_frame(TTSSpeakFrame(text))

        async def finish(self) -> None:
            self.terminal = True

        async def exhausted(self, reason: str) -> None:
            self.status, self.detail, self.terminal = 'exhausted', reason, True
            await call.speak_now(
                "Sorry, I'm going round in circles there. Could you say that again?", origin='exhausted'
            )

        def begin(self, said: str) -> None:
            call.begin_turn()
            call.turn_started(said)
            call._covered = False
            call._return_status = ''
            self.requests = self.invocations = self.hops = 0
            self.run_step = 0
            self.retries = {}
            self.borrowed = self.terminal = False
            self.status, self.detail = 'answered', ''
            self.prepared = []
            self.role = call.state.agent

        async def on_activated(self, args) -> None:
            await super().on_activated(args)
            await self.flow.initialize(self.node())

        async def refresh(self) -> None:
            await self.flow.set_node_from_config(self.node(respond=False))

        def node(self, respond: bool = True) -> NodeConfig:
            functions = []
            role = self.role
            for name, definition in offered(call, role).items():

                async def handle(args, manager, name=name, role=role):
                    if self.invocations >= self.budget.tool_calls:
                        await self.exhausted('eight tool calls')
                        return 'Tool budget exhausted.', NO_RESPONSE
                    if self.terminal:
                        return 'A final output has already completed this reply.', NO_RESPONSE
                    try:
                        current = next(
                            part
                            for part in self.calls
                            if part.tool_name == name and part.tool_call_id not in self.handled
                        )
                        self.handled.add(current.tool_call_id)
                        if name in FILLER:
                            await call.say(
                                pick(f'tool:{name}', FILLER[name]),
                                origin='tool_filler',
                                tool_call_id=current.tool_call_id,
                            )
                        result = await invoke(
                            call, role, name, args, self.calls, current.tool_call_id, self.run_step
                        )
                    except (ValidationError, ModelRetry) as exc:
                        key = 'output' if declared(role)[name].output else name
                        self.retries[key] = self.retries.get(key, 0) + 1
                        if self.retries[key] > self.budget.repair_retries:
                            await self.exhausted('two repair retries')
                            return str(exc), NO_RESPONSE
                        return str(exc), None
                    self.invocations += 1
                    if isinstance(result, Ask):
                        await call.speak_now(result.put(call), origin='ask')
                    if isinstance(result, Handoff):
                        destination = result.to
                        pending = None
                        target = AGENTS[destination]
                        if result.status == 'handoff' and any(
                            not getattr(call.state, field) for field in target.requires
                        ):
                            pending, destination = destination, target.satisfied_by
                        call.commit(agent=destination, pending=pending)
                        self.borrowed = False
                        call._return_status = (
                            f'Application handoff: {role} -> {destination}. '
                            f'You are now {destination}; handle the caller request here. '
                            'The previous handoff finished routing, not the caller request.'
                            if result.status == 'handoff'
                            else f'Application return: {role} {result.status}. '
                            + (
                                'The earlier request was abandoned; do not resume it.'
                                if result.status == 'unserved'
                                else 'Continue the original caller request.'
                            )
                        )
                        self.role = destination
                        self.run_step = 0
                        self.retries = {}
                        self.hops += 1
                        if self.hops >= self.budget.step_runs:
                            await self.exhausted('four step runs')
                            return 'Step budget exhausted.', NO_RESPONSE
                        if lines := AGENTS[destination].enter:
                            await call.say(pick(f'enter:{destination}', lines), origin='entry')
                        return result.model_dump(mode='json'), self.node()
                    if name == 'read_diary' and role == 'concierge':
                        self.borrowed = True
                    payload = result.model_dump(mode='json') if isinstance(result, BaseModel) else result
                    if declared(role)[name].output:
                        self.terminal = True
                        return payload, NO_RESPONSE
                    return payload, None

                schema = definition['parameters_json_schema']
                functions.append(
                    FlowsFunctionSchema(
                        name=name,
                        description=definition['description'],
                        properties=schema.get('properties', {}),
                        required=schema.get('required', []),
                        handler=handle,
                    )
                )
            return {
                'name': role,
                'role_message': prompt(role).render(call),
                'task_messages': [],
                'functions': functions,
                'respond_immediately': respond,
            }

        def response_finished(self) -> None:
            call.close_model_text()
            if self.borrowed:
                call.commit(agent='booking')
            call._return_status = ''
            done.set()

    return MatchedWorker()
