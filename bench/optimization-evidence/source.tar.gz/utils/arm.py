"""What a run was, recorded beside what it measured.

A latency or request-count difference between two arms means nothing without
the two configurations it is a difference between, and "the repository at the
time" is not a record anybody can pair a later run against. Both the offline
benchmark and the live bot write this, so a scripted run and a spoken one can
be compared with each other rather than only with themselves.

Unknown stays unknown. The fields this process cannot see are exactly the
ones that block a strict matched-configuration claim, and leaving them out is
how that block goes unnoticed.
"""

from __future__ import annotations

import hashlib
import os
import pathlib
import subprocess
import sys
from copy import deepcopy
from datetime import UTC, datetime
from functools import cache
from importlib.metadata import version

from salon import diary
from voice.harness import TurnBudget

_ROOT = pathlib.Path(__file__).resolve().parent.parent
# Captured once, at import, and not again. The record a live call used to
# write stamped `started` with the time it *ended*, so every configuration
# figure in it was read as the configuration at the moment of writing --
# which for anything that can change during a call is the wrong moment.
PROCESS_STARTED_AT = datetime.now(UTC).isoformat()


def _digest(paths: list[pathlib.Path]) -> str:
    """One SHA-256 over these files, so a set of them can be named by a number."""
    rolling = hashlib.sha256()
    for path in sorted(paths):
        rolling.update(path.read_bytes())
    return rolling.hexdigest()


def _git(*args: str) -> str:
    return subprocess.run(['git', *args], capture_output=True, text=True, check=False).stdout.strip()


@cache
def _process_settings() -> dict:
    """This arm, as far as this process can see it."""
    from salon import agents

    return {
        'revision': _git('rev-parse', 'HEAD') or 'unknown',
        'uncommitted_changes': bool(_git('status', '--porcelain')),
        'python': sys.version.split()[0],
        'pydantic_ai': version('pydantic-ai-slim'),
        # The id, not `str(model)`: a pinned `GoogleModel` renders as
        # `GoogleModel()`, which records nothing at all about which model ran
        # -- on the one field the whole comparison is most sensitive to.
        'model': getattr(agents.MODEL, 'model_name', None) or str(agents.MODEL),
        'model_pinned': bool(os.getenv('BENCH_PINNED')),
        # Unpinned unless Application Default Credentials exist: an
        # Express-Mode API key has none, so Google routes where it likes.
        'region': getattr(getattr(agents.MODEL, 'client', None), 'location', None) or 'unpinned',
        'model_settings': str(agents.SETTINGS),
        'budget': str(TurnBudget()),  # what the processor is built with
        'speak_by': agents.SPEAK_BY,
        # What the prompts and the lock were, as one number each. Two runs
        # whose prompt digests differ are not the same arm, however alike
        # their settings read.
        'prompt_sha256': _digest(
            sorted(_ROOT.glob('prompts/**/*.md'))
            + sorted(_ROOT.glob('knowledge/*.md'))
            + sorted(_ROOT.glob('knowledge/*.json'))
        ),
        'source_sha256': _digest(
            sorted(_ROOT.glob('salon/*.py'))
            + sorted(_ROOT.glob('voice/*.py'))
            + sorted(_ROOT.glob('utils/*.py'))
            + [_ROOT / 'bot.py']
        ),
        'lock_sha256': _digest([_ROOT / 'uv.lock']) if (_ROOT / 'uv.lock').exists() else '',
        'timezone': str(diary.TZ),
        'salon_clock': diary.now().isoformat(),
        # Whether this call started from an empty salon or inherited the last
        # one's. Two calls are only comparable when they agree on it, and a
        # continuation scenario is only meaningful when they do not.
        'fixture': os.getenv('SALON_FIXTURE', 'continue'),
        # Three different moments, and the record used to carry one number
        # under a name that meant the earliest of them. `process_started_at`
        # is immutable configuration; `captured_at` is when this dict was
        # built, which on a live call is when the call ended.
        'process_started_at': PROCESS_STARTED_AT,
        'captured_at': datetime.now(UTC).isoformat(),
        # What the caller waits out before the agency hears them. Part of
        # every gap measured on this arm, and not a thing the agency can
        # make up for.
        'endpointing_stop_secs': float(os.getenv('SMART_TURN_STOP_SECS', '1.5')),
        'seed_customers': sorted(diary._customers),
        # The rule that decides how many turns a booking takes, and one of the
        # things two arms must match before their turn counts mean the same.
        # This one books on an unambiguous choice of an offered time; the
        # native arm reads the booking back and waits for a separate yes.
        'confirmation_policy': 'books on an unambiguous selection; no separate readback turn',
        # What this process cannot see, and every one of them is a dimension
        # two arms have to match on before a difference between them means
        # anything. Named, because an unknown left out of a record reads as
        # a match.
        'unknown': ['provider endpoint', 'stt/tts route and voice', 'transport', 'audio settings'],
    }


def settings() -> dict:
    """Immutable loaded-process configuration plus this call's starting fixture."""
    result = deepcopy(_process_settings())
    result.update(
        salon_clock=diary.now().isoformat(),
        fixture=os.getenv('SALON_FIXTURE', 'continue'),
        seed_customers=sorted(diary._customers),
        captured_at=datetime.now(UTC).isoformat(),
    )
    return result


def outcome(phone: str) -> dict:
    """What the salon holds now. The diary is in memory, so it dies with the process.

    Which is the whole reason this exists: a live call leaves a trace full of
    timings and no way at all to ask whether it booked the right thing, and a
    benchmark that can only score the turns it can see scores the wrong
    thing quickly.
    """
    return {
        'bookings': diary.bookings_for(phone, diary.now().date()),
        'complaints': [c for c in diary.complaints() if c['phone'] == phone],
    }
